#!/bin/bash

echo "========== DNS =========="
dig +short brain.ayureze.in

echo
echo "========== HTTPS Headers =========="
curl -I https://brain.ayureze.in

echo
echo "========== Health =========="
curl -v https://brain.ayureze.in/health 2>&1 | tail -40

echo
echo "========== Local Port 8000 =========="
curl http://127.0.0.1:8000/health 2>/dev/null || true

echo
echo "========== Docker =========="
docker ps

echo
echo "========== Listening Ports =========="
ss -tulpn | grep -E "8000|80|443"

echo
echo "========== Nginx =========="
docker logs aibackend_proxy --tail 50
