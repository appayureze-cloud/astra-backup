#!/bin/bash
set -e

echo "======================================"
echo " AUTH ENDPOINTS"
echo "======================================"

docker exec aibackend python - <<'PY'
import main

for r in sorted(main.app.routes, key=lambda x: x.path):
    if "/auth/" in r.path:
        methods=",".join(sorted(r.methods))
        print(f"{methods:15} {r.path}")
PY

echo
echo "======================================"
echo " SESSION ENDPOINT"
echo "======================================"

curl -i -X POST http://localhost:5001/api/v1/auth/session \
-H "Content-Type: application/json" \
-d '{}'
