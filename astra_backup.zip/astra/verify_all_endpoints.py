import paramiko
import os

def run_verification():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        print("Connecting to VPS...")
        ssh.connect('82.25.105.156', username='root', password='Ayureze@369369', timeout=10)
        print("Connected.")
        
        # 1. Create a dummy image file inside the container to test upload
        print("Creating a dummy image file inside the container...")
        ssh.exec_command("docker exec aibackend dd if=/dev/zero of=/tmp/test_image.jpg bs=1024 count=10")
        
        # 2. Test endpoints using curl inside the container to isolate any network/nginx proxy issues
        commands = [
            ("Health Check (Main)", "docker exec aibackend curl -s -i http://localhost:5000/health"),
            ("Health Check (v1 API)", "docker exec aibackend curl -s -i http://localhost:5000/api/v1/health"),
            ("Health Check (Brain AI)", "docker exec aibackend curl -s -i http://localhost:5000/v1/health"),
            ("Health Check (Brain API v1)", "docker exec aibackend curl -s -i http://localhost:5000/api/v1/brain/health"),
            ("Test Image Analysis SSE (POST /api/v1/analyze-image)", 
             "docker exec aibackend curl -s -N -X POST -F 'file=@/tmp/test_image.jpg' http://localhost:5000/api/v1/analyze-image"),
            ("Test Companion Chat text-only (POST /api/companion/v2/chat)",
             "docker exec aibackend curl -s -i -X POST -F 'journey_id=test_journey' -F 'message=hello' http://localhost:5000/api/companion/v2/chat"),
            ("Test Companion Chat with image (POST /api/companion/v2/chat)",
             "docker exec aibackend curl -s -i -X POST -F 'journey_id=test_journey' -F 'message=analyze this skin condition' -F 'file=@/tmp/test_image.jpg' http://localhost:5000/api/companion/v2/chat")
        ]
        
        for name, cmd in commands:
            print(f"\n==================================================")
            print(f"TESTING: {name}")
            print(f"COMMAND: {cmd}")
            print(f"==================================================")
            stdin, stdout, stderr = ssh.exec_command(cmd)
            exit_status = stdout.channel.recv_exit_status()
            
            out = stdout.read().decode('utf-8', 'ignore').strip()
            err = stderr.read().decode('utf-8', 'ignore').strip()
            
            if out:
                print(out)
            if err:
                print("Error output:", err)
                
    except Exception as e:
        print(f"Failed: {e}")
    finally:
        ssh.close()

if __name__ == "__main__":
    run_verification()
