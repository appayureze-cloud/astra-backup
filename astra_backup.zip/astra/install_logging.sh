#!/bin/bash
set -e

cd ~/astra/astra

echo "====================================="
echo " STEP 4 - ENTERPRISE LOGGING"
echo "====================================="

mkdir -p app/core
mkdir -p logs

############################################
# logging_config.py
############################################

cat > app/core/logging_config.py <<'PY'
import logging
import os
from logging.handlers import TimedRotatingFileHandler

LOG_DIR="logs"
os.makedirs(LOG_DIR, exist_ok=True)

def create_logger(name,file,level=logging.INFO):

    logger=logging.getLogger(name)

    if logger.handlers:
        return logger

    logger.setLevel(level)

    formatter=logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )

    handler=TimedRotatingFileHandler(
        os.path.join(LOG_DIR,file),
        when="midnight",
        backupCount=30,
        encoding="utf-8"
    )

    handler.setFormatter(formatter)

    logger.addHandler(handler)

    return logger

api_logger=create_logger("api","api.log")
error_logger=create_logger("error","error.log",logging.ERROR)
ai_logger=create_logger("ai","ai.log")
security_logger=create_logger("security","security.log")
scheduler_logger=create_logger("scheduler","scheduler.log")
whatsapp_logger=create_logger("whatsapp","whatsapp.log")
PY

############################################
# request_logging.py
############################################

cat > app/core/request_logging.py <<'PY'
import time

from starlette.middleware.base import BaseHTTPMiddleware
from app.core.logging_config import api_logger

class RequestLoggingMiddleware(BaseHTTPMiddleware):

    async def dispatch(self, request, call_next):

        start=time.time()

        response=await call_next(request)

        elapsed=round((time.time()-start)*1000,2)

        api_logger.info(
            "%s %s %s %.2fms",
            request.method,
            request.url.path,
            response.status_code,
            elapsed
        )

        return response
PY

############################################
# Patch main.py safely
############################################

python3 <<'PY'
from pathlib import Path

path=Path("main.py")
text=path.read_text()

if "RequestLoggingMiddleware" not in text:
    marker="from fastapi import FastAPI"

    if marker in text:
        text=text.replace(
            marker,
            marker+"\nfrom app.core.request_logging import RequestLoggingMiddleware"
        )

if "app.add_middleware(RequestLoggingMiddleware)" not in text:

    if "app = FastAPI(" in text:

        idx=text.find("app = FastAPI(")

        end=text.find(")",idx)

        end=text.find("\n",end)

        text=text[:end]+"\napp.add_middleware(RequestLoggingMiddleware)\n"+text[end:]

path.write_text(text)

print("✓ main.py patched")
PY

############################################
# Docker compose volume
############################################

if [ -f docker-compose.yml ]; then

if ! grep -q "./logs:/app/logs" docker-compose.yml; then

python3 <<'PY'
from pathlib import Path

p=Path("docker-compose.yml")
txt=p.read_text()

lines=txt.splitlines()

out=[]

done=False

for line in lines:

    out.append(line)

    if line.strip()=="volumes:" and not done:
        out.append("      - ./logs:/app/logs")
        done=True

p.write_text("\n".join(out))
PY

fi
fi

############################################

echo
echo "Rebuilding..."

docker compose build

docker compose up -d

echo
echo "Waiting..."

sleep 20

echo
echo "Health"

curl http://localhost:5001/health

echo
echo

curl http://localhost:5001/

echo
echo

echo "Generating log..."

curl http://localhost:5001/health >/dev/null 2>&1

sleep 2

echo
echo "Logs"

ls -lh logs

echo
echo "API Log"

tail -5 logs/api.log || true

echo
echo "Finished."
