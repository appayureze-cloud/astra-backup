"""
Unified Astra Brain Service
"""

import logging
from app.model_service import model_service

logger = logging.getLogger(__name__)

class BrainService:

    async def chat(
        self,
        message: str,
        user_id: str = "",
        channel: str = "app",
        context: str = "",
        **kwargs,
    ):
        logger.info(
            "Brain request channel=%s user=%s",
            channel,
            user_id,
        )

        return await model_service.generate_response(
            prompt=message,
            language="en",
            context=context,
        )

brain_service = BrainService()
