"""
Unified WhatsApp Companion Service
"""

import logging
from typing import Optional

from app.whatsapp.service import WhatsAppService

logger = logging.getLogger(__name__)


class WhatsAppCompanionService:

    def __init__(self):
        self.client = WhatsAppService()
        logger.info("✅ WhatsApp Companion using Unified WhatsAppService")

    async def send_message(
        self,
        to_number: str,
        message: str,
        timeout: float = 30.0,
    ) -> bool:
        try:
            phone = (
                to_number
                .replace("whatsapp:", "")
                .replace("+", "")
                .strip()
            )

            await self.client.send_text(phone, message)
            return True

        except Exception:
            logger.exception("WhatsApp send failed")
            return False

    async def send_document(
        self,
        to_number: str,
        document_url: str,
        caption: Optional[str] = None,
    ) -> bool:
        try:
            phone = (
                to_number
                .replace("whatsapp:", "")
                .replace("+", "")
                .strip()
            )

            await self.client.send_document(
                phone_number=phone,
                document_url=document_url,
                caption=caption,
            )

            return True

        except Exception:
            logger.exception("WhatsApp document send failed")
            return False

    def is_configured(self) -> bool:
        return True


whatsapp_companion_service = WhatsAppCompanionService()
