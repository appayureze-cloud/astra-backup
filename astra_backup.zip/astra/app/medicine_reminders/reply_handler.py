from fastapi import APIRouter, Request
from datetime import datetime, timedelta

router = APIRouter(prefix="/api/v1/api/reminders", tags=["Reminder Replies"])

@router.post("/reply")
async def reminder_reply(request: Request):
    body = await request.json()

    reminder_id = body.get("reminder_id")
    message = (body.get("message") or "").strip().lower()

    if not reminder_id:
        return {"success": False, "error": "Missing reminder_id"}

    from app.database import db_manager
    client = db_manager.client

    res = client.table("medicine_reminders") \
        .select("adherence_count,missed_count,snooze_count") \
        .eq("id", reminder_id) \
        .single() \
        .execute()

    row = res.data or {}

    adherence = row.get("adherence_count", 0)
    missed = row.get("missed_count", 0)
    snooze = row.get("snooze_count", 0)

    if message in ("taken","done","yes"):
        client.table("medicine_reminders").update({
            "status":"taken",
            "adherence_count":adherence+1,
            "updated_at":datetime.utcnow().isoformat()
        }).eq("id",reminder_id).execute()

    elif message in ("skip","missed"):
        client.table("medicine_reminders").update({
            "status":"skipped",
            "missed_count":missed+1,
            "updated_at":datetime.utcnow().isoformat()
        }).eq("id",reminder_id).execute()

    elif message=="snooze":
        client.table("medicine_reminders").update({
            "status":"pending",
            "next_due":(datetime.utcnow()+timedelta(minutes=15)).isoformat(),
            "snooze_count":snooze+1,
            "updated_at":datetime.utcnow().isoformat()
        }).eq("id",reminder_id).execute()

    elif message=="stop":
        client.table("medicine_reminders").update({
            "is_active":False,
            "updated_at":datetime.utcnow().isoformat()
        }).eq("id",reminder_id).execute()

    else:
        return {
            "success":False,
            "error":"Unknown reply",
            "accepted":["Taken","Skip","Snooze","Stop"]
        }

    return {"success":True,"action":message}
