"""Compatibility wrapper for the unified auth package."""

from app.security.auth import *  # noqa: F401,F403
