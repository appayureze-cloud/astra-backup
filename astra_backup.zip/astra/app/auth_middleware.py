"""Security middleware: rate limiting and content safety checks."""

from app.security_utils import detect_prompt_injection, mask_pii

import logging
import time
from collections import defaultdict
from typing import Dict, List, Optional

from fastapi import HTTPException, Request, status

logger = logging.getLogger(__name__)

class RateLimiter:
    def __init__(self, requests_per_minute: int = 60, jail_duration_seconds: int = 3600):
        self.requests_per_minute = requests_per_minute
        self.jail_duration_seconds = jail_duration_seconds
        self.requests: Dict[str, List[float]] = defaultdict(list)
        self.jail_list: Dict[str, float] = {}
        self.violation_count: Dict[str, int] = defaultdict(int)

    def is_allowed(self, client_id: str) -> bool:
        now = time.time()
        if client_id in self.jail_list:
            if now < self.jail_list[client_id]:
                return False
            self.jail_list.pop(client_id, None)
            self.violation_count[client_id] = 0

        minute_ago = now - 60
        self.requests[client_id] = [t for t in self.requests[client_id] if t > minute_ago]
        if len(self.requests[client_id]) >= self.requests_per_minute:
            self.violation_count[client_id] += 1
            if self.violation_count[client_id] >= 5:
                self.jail_list[client_id] = now + self.jail_duration_seconds
                logger.error("Rate limiter jailed %s", client_id)
            return False

        self.requests[client_id].append(now)
        return True

rate_limiter = RateLimiter()

# Per-user rate limiter (stricter limits for authenticated users)
user_rate_limiter = RateLimiter(requests_per_minute=120, jail_duration_seconds=1800)

async def content_safety_check(request: Request) -> None:
    try:
        body = await request.body()
        if not body:
            return
        text = body.decode("utf-8")
        logger.info("Incoming Request Content Trace: %s...", mask_pii(text[:100]))
        if detect_prompt_injection(text):
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Security Violation: Malicious prompt attempt denied.")
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Safety check error: %s", e)
        return

async def rate_limit_check(request: Request) -> None:
    # Try to get user ID from auth header for per-user rate limiting
    auth_header = request.headers.get("Authorization")
    client_id = request.client.host if request.client else "unknown"
    
    if auth_header and auth_header.startswith("Bearer "):
        # Use user-based rate limiting for authenticated requests
        try:
            from app.security.auth.jwt_service import decode_access_token
            token = auth_header.split(" ", 1)[1]
            payload = decode_access_token(token)
            user_id = payload.get("user_id")
            if user_id:
                client_id = f"user:{user_id}"
                if not user_rate_limiter.is_allowed(client_id):
                    raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="Too many requests. Please try again later.")
        except HTTPException:
            raise
        except Exception:
            # Fall back to IP-based if token decode fails
            pass
    
    # IP-based rate limiting as fallback/baseline
    if not rate_limiter.is_allowed(client_id):
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="Too many requests. Please try again later.")

async def request_size_limit(request: Request, max_size: int = 10 * 1024 * 1024) -> None:
    """Limit request body size to prevent DoS (default 10MB)."""
    content_length = request.headers.get("Content-Length")
    if content_length and int(content_length) > max_size:
        raise HTTPException(status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, detail=f"Request too large. Maximum size: {max_size // (1024*1024)}MB")

async def validate_user_access(user_id_from_request: str, authenticated_user: Optional[str] = None) -> None:
    if authenticated_user is None:
        return
    if user_id_from_request != authenticated_user:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied: You cannot access another user's data.")
