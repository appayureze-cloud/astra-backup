"""
Sync Service - The Ecosystem Bridge
Automatically interlinks Admin Backend (MySQL) with Astra AI Database (Supabase)
"""

import logging
import asyncio
from datetime import datetime, timezone
from sqlalchemy import text
from app.database import db_manager
from app.admin_db import admin_db

logger = logging.getLogger(__name__)

class SyncService:
    """Interlinks MySQL (Admin) and Supabase (AI) systems"""
    
    _instance = None
    _is_running = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SyncService, cls).__new__(cls)
        return cls._instance

    async def start_background_sync(self, interval_seconds: int = 3600):
        """
        Runs a periodic sync task in the background.
        Ensures the AI database always reflects the Admin backend.
        """
        if self._is_running:
            logger.info("SyncService is already running in background")
            return
            
        self._is_running = True
        logger.info(f"🔄 Interlink Background Sync started (Interval: {interval_seconds}s)")
        
        while self._is_running:
            try:
                # Run Sync Task
                logger.info("📦 Synchronizing ecosystem data...")
                summary = await self.sync_all()
                logger.info(f"✅ Sync complete: {summary}")
            except Exception as e:
                logger.error(f"❌ Background sync error: {e}")
            
            # Sleep until next sync
            await asyncio.sleep(interval_seconds)

    async def sync_all(self):
        """Perform a full synchronization of doctors and patients using batching"""
        if not admin_db.engine or not db_manager.is_connected() or not db_manager.client:
            return {"error": "Database not connected"}

        supabase = db_manager.client
            
        doctors_synced = 0
        patients_synced = 0
        
        try:
            # 1. SYNC DOCTORS (Batch)
            doctor_records = []
            with admin_db.get_session() as session:
                try:
                    res = session.execute(text(
                        "SELECT d.id, d.name, u.email, u.phone, d.status "
                        "FROM doctor d "
                        "JOIN users u ON d.user_id = u.id"
                    ))
                    for row in res.mappings():
                        doctor_records.append({
                            "unique_id": f"DOC-{row['id']}",
                    "doctor_id": f"DOC-{row['id']}",
                            "name": row['name'],
                            "email": row.get('email', ''),
                            "phone": row.get('phone', ''),
                            "specialization": 'General Physician'
                            # 'is_active' omitted to prevent PGRST204 missing column error
                        })
                except Exception as e:
                    logger.error(f"Failed to fetch doctors from MySQL: {e}")

            if doctor_records:
                # Batch upsert to Supabase (limit per chunk to avoid hitting URL length limits if any)
                chunk_size = 100
                for i in range(0, len(doctor_records), chunk_size):
                    chunk = doctor_records[i:i + chunk_size]
                    supabase.table("doctors").upsert(chunk, on_conflict="unique_id").execute()
                    doctors_synced += len(chunk)
                logger.info(f"📊 Batch synced {doctors_synced} doctors")

            # 2. SYNC PATIENTS (From users table - Batch)
            patient_records = []
            with admin_db.get_session() as session:
                try:
                    # Patients are users who do not exist in doctor table
                    res = session.execute(text(
                        "SELECT u.id, u.name, u.email, u.phone "
                        "FROM users u "
                        "LEFT JOIN doctor d ON u.id = d.user_id "
                        "WHERE d.id IS NULL LIMIT 2000"
                    ))
                    for row in res.mappings():
                        patient_records.append({
                            "patient_id": str(row['id']),
                            "patient_code": f"PAT-{row['id']}",
                            "name": row['name'] or 'Patient',
                            "email": row.get('email', ''),
                            "phone": row.get('phone', ''),
                        })
                except Exception as e:
                    logger.error(f"Failed to fetch patients from MySQL: {e}")

            if patient_records:
                chunk_size = 100
                for i in range(0, len(patient_records), chunk_size):
                    chunk = patient_records[i:i + chunk_size]
                    supabase.table("patient_profiles").upsert(chunk, on_conflict="patient_code").execute()
                    patients_synced += len(chunk)
                logger.info(f"📊 Batch synced {patients_synced} patients")

            return {"doctors": doctors_synced, "patients": patients_synced}
            
        except Exception as e:
            logger.exception("Sync logic error")
            return {"error": str(e)}

# Export singleton
sync_service = SyncService()
