from prometheus_fastapi_instrumentator import Instrumentator
from prometheus_client import Gauge
import threading
import time
import psutil

cpu_gauge = Gauge(
    "astra_cpu_usage_percent",
    "CPU Usage Percent"
)

memory_gauge = Gauge(
    "astra_memory_usage_percent",
    "Memory Usage Percent"
)

def monitor():
    while True:
        cpu_gauge.set(psutil.cpu_percent())
        memory_gauge.set(psutil.virtual_memory().percent)
        time.sleep(5)

def setup_metrics(app):
    Instrumentator(
        should_group_status_codes=True,
        should_ignore_untemplated=True,
        should_instrument_requests_inprogress=True,
    ).instrument(app).expose(app)

    threading.Thread(
        target=monitor,
        daemon=True
    ).start()
