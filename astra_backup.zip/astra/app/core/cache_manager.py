import os
import json
import logging
from typing import Any

import redis

logger = logging.getLogger("cache")

REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")


class CacheManager:
    def __init__(self):
        self.enabled = False
        self.client = None

        try:
            self.client = redis.Redis.from_url(
                REDIS_URL,
                decode_responses=True,
                socket_timeout=2,
                socket_connect_timeout=2,
            )
            self.client.ping()
            self.enabled = True
            logger.info("Redis connected")
        except Exception as e:
            logger.warning(f"Redis unavailable: {e}")

    def get(self, key):
        if not self.enabled:
            return None
        try:
            value = self.client.get(key)
            return json.loads(value) if value else None
        except Exception:
            return None

    def set(self, key, value, ttl=300):
        if not self.enabled:
            return
        try:
            self.client.setex(key, ttl, json.dumps(value, default=str))
        except Exception:
            pass

    def delete(self, key):
        if self.enabled:
            try:
                self.client.delete(key)
            except Exception:
                pass


cache = CacheManager()
