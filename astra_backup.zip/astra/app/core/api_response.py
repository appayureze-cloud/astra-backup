from typing import Any, Optional
from pydantic import BaseModel


class ErrorResponse(BaseModel):
    success: bool = False
    code: Any
    message: str
    details: Optional[Any] = {}


class SuccessResponse(BaseModel):
    success: bool = True
    message: str = "Success"
    data: Optional[Any] = None
