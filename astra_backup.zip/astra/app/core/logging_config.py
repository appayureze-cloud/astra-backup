import logging
import os
from logging.handlers import TimedRotatingFileHandler

LOG_DIR="logs"
os.makedirs(LOG_DIR, exist_ok=True)

def create_logger(name,file,level=logging.INFO):

    logger=logging.getLogger(name)

    if logger.handlers:
        return logger

    logger.setLevel(level)

    formatter=logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )

    handler=TimedRotatingFileHandler(
        os.path.join(LOG_DIR,file),
        when="midnight",
        backupCount=30,
        encoding="utf-8"
    )

    handler.setFormatter(formatter)

    logger.addHandler(handler)

    return logger

api_logger=create_logger("api","api.log")
error_logger=create_logger("error","error.log",logging.ERROR)
ai_logger=create_logger("ai","ai.log")
security_logger=create_logger("security","security.log")
scheduler_logger=create_logger("scheduler","scheduler.log")
whatsapp_logger=create_logger("whatsapp","whatsapp.log")
