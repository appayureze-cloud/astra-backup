from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor


def setup_tracing(app):
    provider = TracerProvider(
        resource=Resource.create({
            "service.name": "astra-backend"
        })
    )

    trace.set_tracer_provider(provider)

    FastAPIInstrumentor.instrument_app(app)

    print("✓ OpenTelemetry tracing enabled")
