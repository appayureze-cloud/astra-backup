import logging
import re
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi.responses import JSONResponse

logger = logging.getLogger("security")

SQL_PATTERNS = [
    r"union\s+select",
    r"drop\s+table",
    r"delete\s+from",
    r"insert\s+into",
    r"update\s+\w+\s+set",
    r"or\s+1=1",
]

class SecurityMiddleware(BaseHTTPMiddleware):

    async def dispatch(self, request, call_next):

        if request.method in ("POST","PUT","PATCH"):
            body = await request.body()

            try:
                text = body.decode().lower()

                for pattern in SQL_PATTERNS:
                    if re.search(pattern, text):
                        logger.warning(
                            "Blocked request from %s",
                            request.client.host
                        )

                        return JSONResponse(
                            status_code=400,
                            content={
                                "success":False,
                                "code":"INVALID_INPUT",
                                "message":"Unsafe request detected",
                                "details":{}
                            }
                        )

            except Exception:
                pass

        response = await call_next(request)

        response.headers["X-Frame-Options"]="DENY"
        response.headers["X-Content-Type-Options"]="nosniff"
        response.headers["Referrer-Policy"]="same-origin"
        response.headers["Permissions-Policy"]="camera=(), microphone=()"
        response.headers["X-XSS-Protection"]="1; mode=block"

        return response
