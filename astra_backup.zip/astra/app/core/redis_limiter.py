import os
import logging
from limits.storage import storage_from_string

logger = logging.getLogger("redis_limiter")

REDIS_URL = os.getenv(
    "REDIS_URL",
    "redis://astra_redis:6379/0"
)

storage = None

try:
    storage = storage_from_string(REDIS_URL)
    storage.check()
    logger.info("✅ Redis distributed rate limiter connected")
except Exception as e:
    logger.warning(f"⚠ Redis rate limiter unavailable: {e}")
