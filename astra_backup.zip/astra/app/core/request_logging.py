import time

from starlette.middleware.base import BaseHTTPMiddleware
from app.core.logging_config import api_logger

class RequestLoggingMiddleware(BaseHTTPMiddleware):

    async def dispatch(self, request, call_next):

        start=time.time()

        response=await call_next(request)

        elapsed=round((time.time()-start)*1000,2)

        api_logger.info(
            "%s %s %s %.2fms",
            request.method,
            request.url.path,
            response.status_code,
            elapsed
        )

        return response
