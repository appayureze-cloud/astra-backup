"""Role and permission definitions for Astra authentication."""

from typing import Dict, List, Literal, Sequence

RoleName = Literal["admin", "doctor", "patient", "superadmin"]

ALL_ROLES: tuple[RoleName, ...] = ("admin", "doctor", "patient", "superadmin")

ROLE_PERMISSIONS: Dict[RoleName, List[str]] = {
    "admin": ["admin:read", "admin:write", "doctor:read", "patient:read"],
    "doctor": ["doctor:read", "doctor:write", "patient:read", "prescription:write"],
    "patient": ["patient:read", "patient:write"],
    "superadmin": ["*"],
}

def normalize_role(role: str | None) -> RoleName:
    value = (role or "").strip().lower()
    if value in ALL_ROLES:
        return value  # type: ignore[return-value]
    return "patient"

def permissions_for_role(role: str | None) -> List[str]:
    normalized = normalize_role(role)
    return ROLE_PERMISSIONS.get(normalized, ROLE_PERMISSIONS["patient"])

def role_allows(user_role: str | None, allowed_roles: Sequence[str]) -> bool:
    normalized = normalize_role(user_role)
    if normalized == "superadmin":
        return True
    return normalized in {normalize_role(role) for role in allowed_roles}
