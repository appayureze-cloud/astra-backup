"""Firebase verification service."""

import logging
import os
from typing import Any, Dict

import firebase_admin
from fastapi import HTTPException, status
from firebase_admin import auth, credentials

logger = logging.getLogger(__name__)

def _ensure_firebase_initialized() -> bool:
    if firebase_admin._apps:
        return True

    credential_path = os.getenv("FIREBASE_CREDENTIAL_PATH", "firebase_service_account.json")
    if not os.path.exists(credential_path):
        logger.error("Firebase credential file missing: %s", credential_path)
        return False

    try:
        firebase_admin.initialize_app(credentials.Certificate(credential_path))
        return True
    except Exception as exc:
        logger.error("Firebase initialization failed: %s", exc)
        return False

def verify_firebase_token(token: str) -> Dict[str, Any]:
    if not _ensure_firebase_initialized():
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Firebase authentication unavailable")

    try:
        decoded = auth.verify_id_token(token)
        uid = decoded.get("uid")
        if not uid:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Firebase token")
        return {
            "firebase_uid": uid,
            "uid": uid,
            "email": decoded.get("email"),
            "name": decoded.get("name"),
            "phone_number": decoded.get("phone_number"),
            "picture": decoded.get("picture"),
            "email_verified": decoded.get("email_verified", False),
            "claims": decoded,
        }
    except HTTPException:
        raise
    except auth.ExpiredIdTokenError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Firebase token expired")
    except auth.InvalidIdTokenError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Firebase token")
    except auth.RevokedIdTokenError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Firebase token revoked")
    except Exception as exc:
        logger.exception("Firebase verification failed")
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Firebase verification failed") from exc
