"""Pydantic schemas for unified authentication."""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .roles import RoleName

class FirebaseSessionRequest(BaseModel):
    firebase_id_token: Optional[str] = Field(default=None, alias="firebase_token")

    class Config:
        allow_population_by_field_name = True

class AuthUser(BaseModel):
    sub: str
    firebase_uid: str
    user_id: str
    doctor_id: Optional[str] = None
    patient_id: Optional[str] = None
    role: RoleName
    email: Optional[str] = None
    name: Optional[str] = None
    permissions: List[str] = Field(default_factory=list)

class AccessTokenClaims(AuthUser):
    iat: int
    exp: int
    iss: str
    jti: Optional[str] = None
    token_type: str = "access"

class RefreshTokenClaims(BaseModel):
    sub: str
    firebase_uid: str
    user_id: str
    role: RoleName
    iat: int
    exp: int
    iss: str
    jti: Optional[str] = None
    token_type: str = "refresh"

class AuthSessionResponse(BaseModel):
    access_token: str
    expires_in: int
    user: AuthUser
    refresh_token: Optional[str] = None

class LegacyDoctorLoginResponse(BaseModel):
    success: bool = True
    msg: str = "Login successful"
    token: str
    data: Dict[str, Any]

class RefreshTokenRequest(BaseModel):
    refresh_token: str
