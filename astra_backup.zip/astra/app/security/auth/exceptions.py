"""Authentication exceptions for unified Astra auth."""

class AuthError(Exception):
    """Base auth error."""

class InvalidTokenError(AuthError):
    """Raised when a JWT is invalid."""

class ExpiredTokenError(AuthError):
    """Raised when a JWT is expired."""

class RevokedTokenError(AuthError):
    """Raised when a JWT has been revoked."""

class InsufficientRoleError(AuthError):
    """Raised when a user does not have the required role."""

class FirebaseVerificationError(AuthError):
    """Raised when Firebase verification fails."""
