"""Unified authentication package for Astra."""

from .dependencies import (
    get_current_user,
    require_admin,
    require_doctor,
    require_patient,
    require_firebase_auth,
    require_doctor_auth,
    require_admin_auth,
)
from .firebase_service import verify_firebase_token
from .jwt_service import (
    create_access_token,
    verify_access_token,
    decode_access_token,
    create_refresh_token,
    verify_refresh_token,
    validate_role,
    revoke_token,
)
from .roles import ROLE_PERMISSIONS, ALL_ROLES
from .schemas import (
    AuthSessionResponse,
    AuthUser,
    FirebaseSessionRequest,
    RefreshTokenRequest,
)
