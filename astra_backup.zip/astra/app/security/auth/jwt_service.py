"""JWT lifecycle management for Astra tokens."""

import hashlib
import logging
import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional, Sequence

import jwt
from fastapi import HTTPException, status

from app.redis_cache import redis_cache

from .exceptions import ExpiredTokenError, InsufficientRoleError, InvalidTokenError, RevokedTokenError
from .roles import ROLE_PERMISSIONS, RoleName, normalize_role, permissions_for_role, role_allows

logger = logging.getLogger(__name__)

ISSUER = os.getenv("ASTRA_JWT_ISSUER", "astra-backend")
ACCESS_TTL_SECONDS = int(os.getenv("ASTRA_JWT_ACCESS_TTL_SECONDS", str(15 * 60)))
REFRESH_TTL_SECONDS = int(os.getenv("ASTRA_JWT_REFRESH_TTL_SECONDS", str(30 * 24 * 60 * 60)))

def _secret() -> str:
    secret = os.getenv("ASTRA_JWT_SECRET")
    if not secret:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="ASTRA_JWT_SECRET is not configured")
    return secret

def _now() -> datetime:
    return datetime.now(timezone.utc)

def _to_int_ts(value: datetime) -> int:
    return int(value.timestamp())

def _revocation_key(jti: str) -> str:
    return jti

def _refresh_token_key(jti: str) -> str:
    return f"refresh:{jti}"

def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()

def revoke_token(jti: str, expires_at: Optional[int] = None, reason: str = "revoked") -> bool:
    if not jti:
        return False
    ttl = None
    if expires_at:
        ttl = max(1, expires_at - _to_int_ts(_now()))
    return redis_cache.set("auth_revoked", _revocation_key(jti), {"reason": reason}, ttl_seconds=ttl)

def _is_revoked(jti: Optional[str]) -> bool:
    return bool(jti and redis_cache.exists("auth_revoked", _revocation_key(jti)))

def _store_refresh_token(jti: str, token_hash: str, expires_at: int) -> bool:
    """Store refresh token hash for rotation detection."""
    ttl = max(1, expires_at - _to_int_ts(_now()))
    return redis_cache.set("auth_refresh_tokens", _refresh_token_key(jti), {"hash": token_hash}, ttl_seconds=ttl)

def _check_and_consume_refresh_token(jti: str, token_hash: str) -> bool:
    """
    Check if refresh token is valid and not reused.
    Returns True if valid and marks as consumed (rotated).
    """
    key = _refresh_token_key(jti)
    stored = redis_cache.get("auth_refresh_tokens", key)
    if not stored:
        return False
    if stored.get("hash") != token_hash:
        # Token reuse detected! Potential token theft.
        logger.critical(f"REFRESH TOKEN REUSE DETECTED for jti={jti}. Possible token theft.")
        # Revoke all tokens for this user as safety measure
        return False
    # Mark as consumed by deleting (rotation)
    redis_cache.delete("auth_refresh_tokens", key)
    return True

def _base_claims(payload: Dict[str, Any], token_type: str, expires_delta: timedelta) -> Dict[str, Any]:
    now = _now()
    exp = now + expires_delta
    claims = {
        "sub": payload["sub"],
        "firebase_uid": payload["firebase_uid"],
        "user_id": payload["user_id"],
        "doctor_id": payload.get("doctor_id"),
        "patient_id": payload.get("patient_id"),
        "role": normalize_role(payload.get("role")),
        "email": payload.get("email"),
        "name": payload.get("name"),
        "permissions": payload.get("permissions") or permissions_for_role(payload.get("role")),
        "iat": _to_int_ts(now),
        "exp": _to_int_ts(exp),
        "iss": ISSUER,
        "jti": str(uuid.uuid4()),
        "token_type": token_type,
    }
    return claims

def create_access_token(payload: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    claims = _base_claims(payload, "access", expires_delta or timedelta(seconds=ACCESS_TTL_SECONDS))
    return jwt.encode(claims, _secret(), algorithm="HS256")

def create_refresh_token(payload: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    claims = _base_claims(payload, "refresh", expires_delta or timedelta(seconds=REFRESH_TTL_SECONDS))
    token = jwt.encode(claims, _secret(), algorithm="HS256")
    # Store hash for rotation detection
    token_hash = _hash_token(token)
    _store_refresh_token(claims["jti"], token_hash, claims["exp"])
    return token

def decode_access_token(token: str) -> Dict[str, Any]:
    try:
        return jwt.decode(token, _secret(), algorithms=["HS256"], issuer=ISSUER, options={"require": ["sub", "exp", "iat", "iss"]})
    except jwt.ExpiredSignatureError as exc:
        raise ExpiredTokenError("Access token expired") from exc
    except jwt.InvalidTokenError as exc:
        raise InvalidTokenError("Invalid access token") from exc

def verify_access_token(token: str) -> Dict[str, Any]:
    payload = decode_access_token(token)
    if payload.get("token_type") not in (None, "access"):
        raise InvalidTokenError("Wrong token type")
    if _is_revoked(payload.get("jti")):
        raise RevokedTokenError("Token revoked")
    return payload

def verify_refresh_token(token: str) -> Dict[str, Any]:
    try:
        payload = jwt.decode(token, _secret(), algorithms=["HS256"], issuer=ISSUER, options={"require": ["sub", "exp", "iat", "iss"]})
    except jwt.ExpiredSignatureError as exc:
        raise ExpiredTokenError("Refresh token expired") from exc
    except jwt.InvalidTokenError as exc:
        raise InvalidTokenError("Invalid refresh token") from exc

    if payload.get("token_type") != "refresh":
        raise InvalidTokenError("Wrong token type")
    if _is_revoked(payload.get("jti")):
        raise RevokedTokenError("Refresh token revoked")
    
    # Check rotation: verify token hasn't been used before
    token_hash = _hash_token(token)
    if not _check_and_consume_refresh_token(payload["jti"], token_hash):
        raise RevokedTokenError("Refresh token already used or invalid (rotation check failed)")
    
    return payload

def validate_role(payload: Dict[str, Any], allowed_roles: str | Sequence[str]) -> Dict[str, Any]:
    roles = [allowed_roles] if isinstance(allowed_roles, str) else list(allowed_roles)
    if not role_allows(payload.get("role"), roles):
        raise InsufficientRoleError("Insufficient role")
    return payload
