from app.whatsapp.service import WhatsAppService


class PrescriptionWhatsApp:
    def __init__(self):
        self.service = WhatsAppService()

    async def send_prescription(self, phone, pdf_url):
        return await self.service.send_document(
            phone,
            pdf_url,
            "📄 Your prescription from Ayureze Healthcare"
        )
