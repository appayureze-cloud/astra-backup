import os
import httpx
import logging

logger = logging.getLogger(__name__)

class WhatsAppClient:
    def __init__(self):
        self.base_url = os.getenv("CUSTOM_WA_API_BASE_URL", "").rstrip("/")
        self.vendor_id = os.getenv("CUSTOM_WA_VENDOR_UID")
        self.token = os.getenv("CUSTOM_WA_BEARER_TOKEN")

        if not all([self.base_url, self.vendor_id, self.token]):
            raise RuntimeError(
                "Missing CUSTOM_WA_API_BASE_URL, CUSTOM_WA_VENDOR_UID or CUSTOM_WA_BEARER_TOKEN"
            )

        self.endpoint = (
            f"{self.base_url}/{self.vendor_id}/contact/send-message"
        )

        self.timeout = httpx.Timeout(30.0)

    async def send_text(self, phone_number: str, message: str):
        payload = {
            "phone_number": phone_number,
            "message_body": message,
        }

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.post(
                self.endpoint,
                params={"token": self.token},
                json=payload,
            )

        logger.info("WhatsApp response: %s", r.text)
        r.raise_for_status()

        return r.json()
