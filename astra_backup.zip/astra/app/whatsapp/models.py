from dataclasses import dataclass
from typing import Optional

@dataclass
class WhatsAppMessage:
    phone_number: str
    message_body: str
    media_url: Optional[str] = None
