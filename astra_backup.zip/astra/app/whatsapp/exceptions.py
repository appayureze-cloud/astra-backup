class WhatsAppError(Exception):
    """Base WhatsApp exception."""
    pass

class WhatsAppConfigurationError(WhatsAppError):
    pass

class WhatsAppSendError(WhatsAppError):
    pass
