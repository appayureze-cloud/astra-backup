from app.whatsapp.service import WhatsAppService


class CompanionWhatsApp:
    def __init__(self):
        self.service = WhatsAppService()

    async def send_message(self, phone, text):
        return await self.service.send_text(phone, text)
