from app.whatsapp.service import WhatsAppService


class ReminderWhatsApp:
    def __init__(self):
        self.service = WhatsAppService()

    async def send_reminder(self, phone, text):
        return await self.service.send_text(
            phone,
            f"💊 Medicine Reminder\n\n{text}"
        )
