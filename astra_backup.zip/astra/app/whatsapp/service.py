from app.whatsapp.client import WhatsAppClient


class WhatsAppService:
    def __init__(self):
        self.client = WhatsAppClient()

    async def send_text(self, phone_number: str, message: str):
        return await self.client.send_text(phone_number, message)

    async def send_document(self, phone_number: str, document_url: str, caption: str | None = None):
        body = f"{caption}\n{document_url}" if caption else document_url
        return await self.client.send_text(phone_number, body)
