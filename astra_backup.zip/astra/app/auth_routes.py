import logging
import os
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

from fastapi import APIRouter, Depends, HTTPException, Request, status, Body
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy import text

from app.admin_db import admin_db
from app.session_manager import session_manager
from app.database import db_manager
from app.language_utils import language_manager
from app.security.auth import (
    AuthSessionResponse,
    AuthUser,
    FirebaseSessionRequest,
    RefreshTokenRequest,
    create_access_token,
    create_refresh_token,
    decode_access_token,
    revoke_token,
    verify_firebase_token,
    verify_refresh_token,
)
from app.security.auth.roles import normalize_role, permissions_for_role
from app.security.auth.dependencies import get_current_user
from app.audit_logger import audit_logger

logger = logging.getLogger(__name__)

auth_router = APIRouter(prefix="/auth", tags=["authentication"])

# Chat router for Supabase session-based authentication (Flutter compatibility)
chat_router = APIRouter(prefix="/chat", tags=["authenticated-chat"])


class AuthenticatedChatRequest(BaseModel):
    message: str
    session_token: Optional[str] = None
    language: Optional[str] = None
    mode: Optional[str] = "wellness"
    max_length: Optional[int] = 1024
    temperature: Optional[float] = 0.7
    top_p: Optional[float] = 0.9
    top_k: Optional[int] = 50
    do_sample: Optional[bool] = True


class ChatHistoryRequest(BaseModel):
    session_token: str
    session_id: Optional[str] = None
    limit: Optional[int] = 50


def _extract_firebase_token(request: Request, body: Optional[FirebaseSessionRequest]) -> Optional[str]:
    auth_header = request.headers.get("authorization")
    if auth_header and auth_header.lower().startswith("bearer "):
        return auth_header.split(" ", 1)[1].strip() or None
    if body and body.firebase_id_token:
        return body.firebase_id_token.strip() or None
    return request.query_params.get("firebase_id_token")


def _legacy_user_summary(user: Dict[str, Any], record: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    source = record or {}
    return {
        "id": str(source.get("doctor_id") or source.get("patient_id") or source.get("id") or user["user_id"]),
        "name": source.get("name") or user.get("name") or "",
        "phone": source.get("phone") or user.get("phone_number") or "",
        "email": source.get("email") or user.get("email") or "",
        "image": source.get("profile_image") or source.get("image") or "",
        "fullImage": source.get("full_profile_image_url") or source.get("profile_image") or source.get("image") or "",
        "is_filled": 1 if source.get("profile_completed") or source.get("is_filled") else 0,
    }


def _normalize_access_user(payload: Dict[str, Any]) -> AuthUser:
    return AuthUser(
        sub=payload["sub"],
        firebase_uid=payload["firebase_uid"],
        user_id=payload["user_id"],
        doctor_id=payload.get("doctor_id"),
        patient_id=payload.get("patient_id"),
        role=normalize_role(payload.get("role")),
        email=payload.get("email"),
        name=payload.get("name"),
        permissions=payload.get("permissions") or permissions_for_role(payload.get("role")),
    )


# Whitelist of allowed tables for identity lookup
ALLOWED_LOOKUP_TABLES = {
    "doctors",
    "doctors",
    "doctor",
    "patient_profiles",
    "patients",
    "users",
    "admin_users",
}

def _lookup_sql_record(table: str, email: Optional[str], phone: Optional[str]) -> Optional[Dict[str, Any]]:
    if not admin_db.engine:
        return None
    # Prevent SQL injection: validate table name against whitelist
    if table not in ALLOWED_LOOKUP_TABLES:
        logger.error("Invalid table name for lookup: %s", table)
        return None
    with admin_db.get_session() as session:
        clauses = []
        params: Dict[str, Any] = {}
        if email:
            clauses.append("email = :email")
            params["email"] = email
        if phone:
            clauses.append("phone = :phone")
            params["phone"] = phone
        if not clauses:
            return None
        sql = f"SELECT * FROM {table} WHERE {' OR '.join(clauses)} LIMIT 1"
        try:
            result = session.execute(text(sql), params).mappings().first()
            return dict(result) if result else None
        except Exception:
            return None



async def _resolve_identity(firebase_user):
    email = (firebase_user.get("email") or "").lower()
    phone = firebase_user.get("phone_number")

    doctor = _lookup_sql_record("doctors", email, phone)
    if doctor:
        role = "doctor"
        identity = {
            "sub": firebase_user["firebase_uid"],
            "firebase_uid": firebase_user["firebase_uid"],
            "user_id": doctor.get("doctor_id") or doctor.get("id"),
            "doctor_id": doctor.get("doctor_id"),
            "patient_id": None,
            "role": "doctor",
            "email": doctor.get("email"),
            "name": doctor.get("name"),
            "permissions": permissions_for_role("doctor"),
        }
        return identity, doctor

    patient = (
        _lookup_sql_record("patient_profiles", email, phone)
        or _lookup_sql_record("patients", email, phone)
    )
    if patient:
        identity = {
            "sub": firebase_user["firebase_uid"],
            "firebase_uid": firebase_user["firebase_uid"],
            "user_id": patient.get("patient_id") or patient.get("id"),
            "doctor_id": None,
            "patient_id": patient.get("patient_id"),
            "role": "patient",
            "email": patient.get("email"),
            "name": patient.get("name"),
            "permissions": permissions_for_role("patient"),
        }
        return identity, patient

    identity = {
        "sub": firebase_user["firebase_uid"],
        "firebase_uid": firebase_user["firebase_uid"],
        "user_id": firebase_user["firebase_uid"],
        "doctor_id": None,
        "patient_id": None,
        "role": "patient",
        "email": email,
        "name": firebase_user.get("name"),
        "permissions": permissions_for_role("patient"),
    }
    return identity, None



async def _issue_session(firebase_user: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]], Dict[str, Any]]:
    identity, record = await _resolve_identity(firebase_user)
    access_token = create_access_token(identity)
    refresh_token = create_refresh_token(identity)
    claims = decode_access_token(access_token)
    identity["jti"] = claims.get("jti")
    return identity, record, {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "expires_in": int(claims["exp"] - claims["iat"]),
        "user": _normalize_access_user(identity),
    }


@auth_router.get("/health")
async def auth_health():
    """Check auth system status"""
    return {"service": "Authentication", "status": "active"}


@auth_router.post("/session", response_model=AuthSessionResponse)
async def create_session(request: Request, body: Optional[FirebaseSessionRequest] = Body(default=None)):
    """Exchange a Firebase ID token for an Astra JWT session."""
    firebase_token = _extract_firebase_token(request, body)
    if not firebase_token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Firebase ID token required")

    firebase_user = verify_firebase_token(firebase_token)
    identity, record, session_data = await _issue_session(firebase_user)
    
    # Audit log: login event
    audit_logger.log_event(
        event_type="user_login",
        actor_id=identity["user_id"],
        action_details=f"User logged in via Firebase (role: {identity['role']})",
        payload={
            "firebase_uid": identity["firebase_uid"],
            "role": identity["role"],
            "email": identity.get("email"),
            "doctor_id": identity.get("doctor_id"),
            "patient_id": identity.get("patient_id"),
        },
        session_id=identity.get("jti"),
    )
    
    return AuthSessionResponse(**session_data)


@auth_router.get("/user", response_model=AuthUser)
async def get_user_info_endpoint(user_info: Dict[str, Any] = Depends(get_current_user)):
    return _normalize_access_user(user_info)


@auth_router.post("/refresh", response_model=AuthSessionResponse)
async def refresh_session(request: Request, body: Optional[RefreshTokenRequest] = Body(default=None)):
    token = body.refresh_token if body else None
    if not token:
        auth_header = request.headers.get("authorization")
        if auth_header and auth_header.lower().startswith("bearer "):
            token = auth_header.split(" ", 1)[1].strip()
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Refresh token required")

    claims = verify_refresh_token(token)
    revoke_token(claims.get("jti"), expires_at=claims.get("exp"), reason="rotated")
    identity = {
        "sub": claims["sub"],
        "firebase_uid": claims["firebase_uid"],
        "user_id": claims["user_id"],
        "doctor_id": None,
        "patient_id": None,
        "role": claims.get("role"),
        "email": None,
        "name": None,
        "permissions": permissions_for_role(claims.get("role")),
    }
    access_token = create_access_token(identity)
    refresh_token = create_refresh_token(identity)
    payload = decode_access_token(access_token)
    
    # Audit log: token refresh
    audit_logger.log_event(
        event_type="token_refresh",
        actor_id=claims["user_id"],
        action_details="Access token refreshed via refresh token rotation",
        payload={"firebase_uid": claims["firebase_uid"], "role": claims.get("role")},
        session_id=claims.get("jti"),
    )
    
    return AuthSessionResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=int(payload["exp"] - payload["iat"]),
        user=_normalize_access_user(identity),
    )


@auth_router.post("/logout")
async def logout(token: str):
    """Invalidate a legacy session token or revoke an Astra JWT."""
    if token.count(".") == 2:
        claims = decode_access_token(token)
        revoke_token(claims.get("jti"), expires_at=claims.get("exp"), reason="logout")
        
        # Audit log: logout
        audit_logger.log_event(
            event_type="user_logout",
            actor_id=claims["user_id"],
            action_details="User logged out, JWT revoked",
            payload={"firebase_uid": claims["firebase_uid"], "role": claims.get("role")},
            session_id=claims.get("jti"),
        )
        return {"message": "Logged out successfully"}

    success = await session_manager.invalidate_session(token)
    if not success:
        raise HTTPException(status_code=404, detail="Session not found or already invalid")
    return {"message": "Logged out successfully"}


@auth_router.get("/login")
async def doctor_login(request: Request):
    """Legacy login endpoint for Flutter compatibility. Returns legacy format."""
    firebase_token = _extract_firebase_token(request, None)
    if not firebase_token:
        return JSONResponse(status_code=401, content={"success": False, "detail": "Missing Bearer Token"})

    try:
        firebase_user = verify_firebase_token(firebase_token)
        identity, record, session_data = await _issue_session(firebase_user)
        legacy_data = _legacy_user_summary(identity, record)
        user_payload = session_data["user"].dict() if hasattr(session_data["user"], "dict") else session_data["user"].model_dump()
        
        # Audit log: legacy login
        audit_logger.log_event(
            event_type="legacy_login",
            actor_id=identity["user_id"],
            action_details="Legacy login endpoint used (Flutter compatibility)",
            payload={"firebase_uid": identity["firebase_uid"], "role": identity["role"]},
            session_id=identity.get("jti"),
        )
        
        return {
            "success": True,
            "msg": "Login successful",
            "token": session_data["access_token"],
            "access_token": session_data["access_token"],
            "expires_in": session_data["expires_in"],
            "refresh_token": session_data["refresh_token"],
            "user": user_payload,
            "data": {**legacy_data, "token": session_data["access_token"], "access_token": session_data["access_token"], "expires_in": session_data["expires_in"], "user": user_payload, "refresh_token": session_data["refresh_token"]},
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Auth Error: %s", e)
        return JSONResponse(status_code=401, content={"success": False, "detail": "Invalid Firebase Token"})


@chat_router.post("/message", response_model=Dict[str, Any])
async def authenticated_chat(request: AuthenticatedChatRequest):
    """
    The Main Astra Pipeline Entry Point.
    1. Validates Session (Supabase)
    2. Detects Language
    3. Retrieves RAG History (Astra Memory)
    4. Generates Response
    5. Saves to DB (Supabase)
    """
    try:
        # 1. Validate Session
        session_info = await session_manager.get_session(request.session_token)
        if not session_info:
            raise HTTPException(status_code=401, detail="Invalid or expired session")

        user_id = session_info["user_id"]
        session_id = session_info["session_id"]

        # 2. Language & Context Analysis
        detected_language = request.language or language_manager.detect_language(request.message)
        is_ayurveda_related = language_manager.is_ayurveda_related(
            request.message, detected_language
        )

        # Lazy import to avoid circular dependencies during app startup
        from app.astra.routes import pipeline_instance, rag_memory_instance

        # 3. Retrieve History
        history = rag_memory_instance.get_history(user_id)

        # 4. Generate Response
        # 4. Generate Response (Pipeline already saves to Supabase)
        response_text = await pipeline_instance.process_query(
            user_id=user_id,
            message=request.message,
            history=history
        )
        
        # 5. Update Local Cache (Optional - if needed for performance)
        rag_memory_instance.add_message(user_id, "user", request.message)
        rag_memory_instance.add_message(user_id, "assistant", response_text)

        return {
            "response": response_text,
            "session_id": session_id,
            "user_id": user_id,
            "language": detected_language,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in companion chat: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@chat_router.post("/history", response_model=List[Dict[str, Any]])
async def get_chat_history(request: ChatHistoryRequest):
    """
    Retrieve chat history for a specific session.
    """
    # Validate session owner
    session_info = await session_manager.get_session(request.session_token)
    if not session_info:
        raise HTTPException(status_code=401, detail="Invalid session")

    # TODO: Ensure request.session_id belongs to the user in session_info
    # (Optional additional security check, depending on your DB logic)

    return await db_manager.get_chat_history(
        session_id=request.session_id,
        limit=request.limit or 50
    )


@chat_router.get("/sessions")
async def get_user_sessions(session_token: str):
    """
    Get all active sessions for the user.
    """
    session_info = await session_manager.get_session(session_token)
    if not session_info:
        raise HTTPException(status_code=401, detail="Invalid session")

    sessions = await db_manager.get_user_sessions(session_info["user_id"])

    return {
        "sessions": sessions,
        "total_count": len(sessions)
    }
