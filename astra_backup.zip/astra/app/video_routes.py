import os
import time
import logging
from fastapi import APIRouter, HTTPException, Query
from agora_token_builder import RtcTokenBuilder

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/video", tags=["Agora Video Calls"])

# Get Agora configuration from env with fallback to user's credentials
AGORA_APP_ID = os.getenv("AGORA_APP_ID", "aaf7c4d9c2d849368b79b1583e5023ed")
AGORA_APP_CERTIFICATE = os.getenv("AGORA_APP_CERTIFICATE", "669fcfe648894e709af71efd7f2068ae")

@router.get("/token")
def get_agora_token(
    channel: str = Query(..., description="The channel/room name (e.g. consultation ID)"),
    uid: str = Query("0", description="User ID (can be numeric string or alphanumeric account)"),
    role: str = Query("publisher", description="Role: publisher or subscriber"),
    expiry: int = Query(3600, description="Token validity duration in seconds")
):
    """
    Generate an Agora RTC token for patient-doctor video consultation.
    """
    try:
        if not AGORA_APP_ID or not AGORA_APP_CERTIFICATE:
            raise HTTPException(status_code=500, detail="Agora server credentials are not configured")

        # Map role string to Agora role integer (1 = publisher, 2 = subscriber)
        agora_role = 1 if role.lower() == "publisher" else 2

        # Calculate privilege expiration timestamp
        privilege_expired_ts = int(time.time()) + expiry

        # Build token based on UID type (numeric UID vs alphanumeric string account)
        if uid.isdigit():
            numeric_uid = int(uid)
            token = RtcTokenBuilder.buildTokenWithUid(
                AGORA_APP_ID,
                AGORA_APP_CERTIFICATE,
                channel,
                numeric_uid,
                agora_role,
                privilege_expired_ts
            )
        else:
            token = RtcTokenBuilder.buildTokenWithAccount(
                AGORA_APP_ID,
                AGORA_APP_CERTIFICATE,
                channel,
                uid,
                agora_role,
                privilege_expired_ts
            )

        logger.info(f"Agora RTC token generated for channel '{channel}' and uid '{uid}'")
        return {
            "success": True,
            "token": token,
            "channel": channel,
            "uid": uid,
            "role": role,
            "expiry_timestamp": privilege_expired_ts
        }
    except Exception as e:
        logger.error(f"Failed to generate Agora token: {e}")
        raise HTTPException(status_code=500, detail=str(e))
