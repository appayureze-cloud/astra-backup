import paramiko

def debug_vps_curl():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        print("Connecting to VPS...")
        ssh.connect('82.25.105.156', username='root', password='Ayureze@369369', timeout=10)
        print("Connected.")
        
        # Verbose curl
        cmd = "docker exec aibackend curl -v -X POST -F 'file=@/tmp/test_image.jpg' http://localhost:5000/api/v1/analyze-image"
        print(f"Executing: {cmd}")
        stdin, stdout, stderr = ssh.exec_command(cmd)
        exit_status = stdout.channel.recv_exit_status()
        
        print("=== STDOUT ===")
        print(stdout.read().decode('utf-8', 'ignore'))
        print("=== STDERR ===")
        print(stderr.read().decode('utf-8', 'ignore'))
        
    except Exception as e:
        print(f"Failed: {e}")
    finally:
        ssh.close()

if __name__ == "__main__":
    debug_vps_curl()
