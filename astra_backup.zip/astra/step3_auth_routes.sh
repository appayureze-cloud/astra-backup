#!/bin/bash

echo "======================================"
echo " AUTH ROUTES"
echo "======================================"

echo
echo "===== auth_routes.py ====="
sed -n '1,250p' app/auth_routes.py

echo
echo "===== doctor_auth_routes.py ====="
sed -n '1,250p' app/doctors/doctor_auth_routes.py

echo
echo "===== jwt_service.py ====="
sed -n '1,250p' app/security/auth/jwt_service.py

echo
echo "======================================"
echo " DONE"
echo "======================================"

