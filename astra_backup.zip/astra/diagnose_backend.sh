#!/bin/bash
set -e

echo "===== CONTAINER STATUS ====="
docker ps -a

echo
echo "===== LAST 80 LOGS ====="
docker logs --tail=80 aibackend || true

echo
echo "===== HEALTH ====="
docker inspect -f '{{json .State.Health}}' aibackend 2>/dev/null || true

echo
echo "===== MAIN.PY (lines 1-50) ====="
nl -ba main.py | sed -n '1,50p'

echo
echo "===== JSON LOGGING IMPORT ====="
grep -n "setup_json_logging" main.py || true
