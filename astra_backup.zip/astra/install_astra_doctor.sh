#!/bin/bash

echo "Installing Astra Doctor..."

apt-get update -y >/dev/null 2>&1
apt-get install -y curl jq bc openssl >/dev/null 2>&1

cat > astra_doctor.sh <<'SCRIPT'
#!/usr/bin/env bash

echo "========================================"
echo "ASTRA DOCTOR"
echo "========================================"

API="${1:-https://astra.ayureze.in}"

echo
echo "[1] Health"
curl -sk "$API/health" || true

echo
echo "[2] OpenAPI"
curl -sk "$API/openapi.json" -o /tmp/openapi.json

if [ ! -f /tmp/openapi.json ]; then
    echo "OpenAPI not found"
    exit 1
fi

echo "Routes: $(jq '.paths|length' /tmp/openapi.json)"

echo
echo "[3] Testing GET endpoints"

jq -r '.paths|to_entries[]|select(.value.get)|.key' /tmp/openapi.json |
while read ep
do
    code=$(curl -ks -o /dev/null -w "%{http_code}" "$API$ep")
    printf "%-70s %s\n" "$ep" "$code"
done

echo
echo "Done."
SCRIPT

chmod +x astra_doctor.sh

echo
echo "Installation Complete."
echo
echo "Run:"
echo "./astra_doctor.sh"

