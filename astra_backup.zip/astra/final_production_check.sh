#!/bin/bash

echo "=============================="
echo "ASTRA FINAL PRODUCTION CHECK"
echo "=============================="

echo
echo "[1] Containers"
docker ps

echo
echo "[2] Backend"
curl -s http://localhost:5001/health

echo
echo "[3] API v1"
curl -s -o /dev/null -w "%{http_code}\n" http://localhost:5001/api/v1/health

echo
echo "[4] Brain"
curl -s https://brain.ayureze.in/health

echo
echo "[5] Firebase"
docker logs aibackend 2>&1 | grep -i "firebase initialized" || true

echo
echo "[6] Duplicate warnings"
docker logs aibackend 2>&1 | grep -i "Duplicate Operation" || echo "PASS"

echo
echo "[7] 500 Errors"
docker logs aibackend 2>&1 | grep "500 Internal Server Error" || echo "PASS"

echo
echo "[8] Tracebacks"
docker logs aibackend 2>&1 | grep Traceback || echo "PASS"

echo
echo "[9] JWT"
docker exec aibackend env | grep ASTRA_JWT

echo
echo "[10] Production Score"

score=100

docker logs aibackend 2>&1 | grep -q Traceback && score=$((score-15))
docker logs aibackend 2>&1 | grep -q "500 Internal Server Error" && score=$((score-15))
curl -s https://brain.ayureze.in/health | grep -q online || score=$((score-5))

echo
echo "Production Score: ${score}%"
