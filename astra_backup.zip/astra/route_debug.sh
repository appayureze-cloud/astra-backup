#!/bin/bash

BASE=http://localhost:5001

echo "===== DIRECT REQUESTS ====="

for ep in \
"/api/v1/orders/prescription/save" \
"/api/v1/video/history" \
"/api/v1/api/reminders/health"
do
    echo
    echo ">>> $ep"
    curl -i "$BASE$ep"
done

echo
echo "===== OPENAPI ====="
curl -s "$BASE/openapi.json" | grep -E "orders|video|reminders" | head -100

echo
echo "===== BACKEND LOGS ====="
docker logs aibackend --tail 100
