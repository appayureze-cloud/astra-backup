#!/bin/bash
set -e

echo "======================================"
echo " LOGIN FLOW READINESS"
echo "======================================"

echo
echo "[1] Session endpoint"
curl -s -o /dev/null -w "%{http_code}\n" \
-X POST http://localhost:5001/api/v1/auth/session \
-H "Content-Type: application/json" \
-d '{}'

echo
echo "[2] Refresh endpoint"
curl -s -o /dev/null -w "%{http_code}\n" \
-X POST http://localhost:5001/api/v1/auth/refresh \
-H "Content-Type: application/json" \
-d '{}'

echo
echo "[3] Protected endpoint"
curl -s -o /dev/null -w "%{http_code}\n" \
http://localhost:5001/api/v1/auth/user

echo
echo "======================================"
echo " READY FOR REAL FIREBASE LOGIN"
echo "======================================"
