#!/bin/bash
set -e

echo "======================================"
echo " REFRESH ENDPOINT CHECK"
echo "======================================"

echo
echo "1. Route definition"
grep -n "refresh_session" app/auth_routes.py

echo
echo "2. Refresh request model"
grep -n -A20 "class RefreshTokenRequest" app/auth_routes.py

echo
echo "3. Refresh endpoint"
grep -n -A30 "@auth_router.post(\"/refresh\"" app/auth_routes.py

echo
echo "======================================"
echo " DONE"
echo "======================================"
