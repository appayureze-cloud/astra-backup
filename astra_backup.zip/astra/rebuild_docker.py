import paramiko

def rebuild_docker():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        print("Connecting to VPS...")
        ssh.connect('82.25.105.156', username='root', password='Ayureze@369369', timeout=10)
        
        print("Rebuilding Docker image on VPS (this may take a minute)...")
        stdin, stdout, stderr = ssh.exec_command('cd /opt/astra && docker compose -f docker-compose.yml build backend')
        print(stdout.read().decode())
        print(stderr.read().decode())
        
        print("Restarting backend container with new image...")
        stdin, stdout, stderr = ssh.exec_command('cd /opt/astra && docker compose -f docker-compose.yml up -d backend')
        print(stdout.read().decode())
        print(stderr.read().decode())
        
        print("Successfully rebuilt and restarted backend!")
    except Exception as e:
        print(f"Failed: {e}")
    finally:
        ssh.close()

if __name__ == "__main__":
    rebuild_docker()
