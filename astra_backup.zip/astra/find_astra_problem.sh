#!/bin/bash

echo "======================================================"
echo "        ASTRA ROUTER & DEPLOYMENT DIAGNOSTIC"
echo "======================================================"

echo
echo "[1] Current directory"
pwd

echo
echo "[2] main.py locations"
find /root -path "*/app/main.py"

echo
echo "[3] Docker mounts"
docker inspect aibackend --format '{{range .Mounts}}{{println .Source "->" .Destination}}{{end}}'

echo
echo "[4] Docker startup command"
docker inspect aibackend --format '{{.Config.Cmd}}'

echo
echo "[5] Docker working directory"
docker inspect aibackend --format '{{.Config.WorkingDir}}'

echo
echo "[6] include_router lines"
grep -n "include_router" /root/astra/astra/app/main.py || true

echo
echo "[7] Router imports"
grep -n "^from app.*router" /root/astra/astra/app/main.py || true

echo
echo "[8] Registered FastAPI routes"
docker exec aibackend python -c "
from app.main import app
print('='*70)
for r in sorted(app.routes,key=lambda x:x.path):
    print(','.join(sorted(r.methods)), r.path)
"

echo
echo "[9] Missing router files"
for f in \
doctor_routes.py \
patient_management.py \
auth_routes.py \
brain_api.py \
order_management.py \
notification_routes.py \
shopify_webhook.py
do
find /root/astra/astra -name \$f
done

echo
echo "======================================================"
echo "DONE"
echo "======================================================"
