#!/bin/bash
set -e

echo "========== STEP 5 : PROMETHEUS METRICS =========="

# ------------------------------------------------------------------
# Install dependencies
# ------------------------------------------------------------------

grep -q "prometheus-fastapi-instrumentator" requirements.txt || cat >> requirements.txt <<REQ

prometheus-fastapi-instrumentator>=7.0.0
prometheus-client>=0.20.0
psutil>=6.0.0
REQ

echo "✓ requirements updated"

# ------------------------------------------------------------------
# Create metrics module
# ------------------------------------------------------------------

mkdir -p app/core

cat > app/core/metrics.py <<'PY'
from prometheus_fastapi_instrumentator import Instrumentator
from prometheus_client import Gauge
import threading
import time
import psutil

cpu_gauge = Gauge(
    "astra_cpu_usage_percent",
    "CPU Usage Percent"
)

memory_gauge = Gauge(
    "astra_memory_usage_percent",
    "Memory Usage Percent"
)

def monitor():
    while True:
        cpu_gauge.set(psutil.cpu_percent())
        memory_gauge.set(psutil.virtual_memory().percent)
        time.sleep(5)

def setup_metrics(app):
    Instrumentator(
        should_group_status_codes=True,
        should_ignore_untemplated=True,
        should_instrument_requests_inprogress=True,
    ).instrument(app).expose(app)

    threading.Thread(
        target=monitor,
        daemon=True
    ).start()
PY

echo "✓ metrics.py created"

# ------------------------------------------------------------------
# Patch main.py
# ------------------------------------------------------------------

python3 <<'PY'
from pathlib import Path

p=Path("main.py")
text=p.read_text()

if "setup_metrics" not in text:

    if "from app.core.metrics import setup_metrics" not in text:
        text="from app.core.metrics import setup_metrics\n"+text

    idx=text.find("app = FastAPI")

    if idx!=-1:
        end=text.find("\n",idx)
        text=text[:end+1]+"setup_metrics(app)\n"+text[end+1:]

p.write_text(text)

print("✓ main.py patched")
PY

# ------------------------------------------------------------------
# Rebuild
# ------------------------------------------------------------------

docker compose down

docker compose build

docker compose up -d

echo
echo "Waiting..."
sleep 25

echo
echo "========== HEALTH =========="
curl http://localhost:5001/health

echo
echo
echo "========== METRICS =========="
curl http://localhost:5001/metrics | head -30

