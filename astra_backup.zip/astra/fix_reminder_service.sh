#!/bin/bash
set -e

FILE=app/medicine_reminders/supabase_reminder_service.py

cp "$FILE" "$FILE.bak.$(date +%s)"

python3 <<'PY'
from pathlib import Path

p=Path("app/medicine_reminders/supabase_reminder_service.py")
text=p.read_text()

if "def get_pending_reminders(" not in text:

    insert='''
    def get_pending_reminders(self):
        """Get reminders pending now."""
        if not db_manager.is_connected():
            return []
        try:
            res=db_manager.client.table("medicine_reminders")\
                .select("*")\
                .eq("is_active",True)\
                .execute()
            return res.data or []
        except Exception as e:
            logger.error(f"Error getting pending reminders: {e}")
            return []

    def get_reminder(self, reminder_id:str):
        try:
            res=db_manager.client.table("medicine_reminders")\
                .select("*")\
                .eq("id",reminder_id)\
                .single()\
                .execute()
            return res.data
        except Exception:
            return None

    def update_reminder(self, reminder_id:str, updates:dict):
        try:
            db_manager.client.table("medicine_reminders")\
                .update(updates)\
                .eq("id",reminder_id)\
                .execute()
            return True
        except Exception as e:
            logger.error(e)
            return False

    def delete_reminder(self, reminder_id:str):
        try:
            db_manager.client.table("medicine_reminders")\
                .update({"is_active":False})\
                .eq("id",reminder_id)\
                .execute()
            return True
        except Exception as e:
            logger.error(e)
            return False

    def log_adherence(self, reminder_id:str, taken:bool, timestamp=None):
        from datetime import datetime
        try:
            db_manager.client.table("medicine_adherence").insert({
                "reminder_id": reminder_id,
                "taken": taken,
                "timestamp": (timestamp or datetime.utcnow().isoformat())
            }).execute()
            return True
        except Exception as e:
            logger.error(e)
            return False
'''

    text=text.replace(
        "# Global instance",
        insert+"\n# Global instance"
    )

    p.write_text(text)
    print("Patched successfully.")
else:
    print("Already patched.")
PY

docker compose build backend
docker compose up -d backend

sleep 10

curl http://localhost:5001/api/v1/api/reminders/health
echo
curl http://localhost:5001/api/v1/api/reminders/pending/now
