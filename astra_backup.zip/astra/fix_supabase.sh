#!/bin/bash
set -e

echo "===== SUPABASE DIAGNOSTICS ====="

echo
echo "1. SUPABASE_URL"
docker exec aibackend printenv SUPABASE_URL || true

echo
echo "2. SUPABASE KEYS"
docker exec aibackend printenv | grep SUPABASE || true

echo
echo "3. DNS"
docker exec aibackend python -c "import socket; print(socket.gethostbyname('ykewayjfdanhqtqpziwt.supabase.co'))" || true

echo
echo "4. HTTPS"
docker exec aibackend curl -I https://ykewayjfdanhqtqpziwt.supabase.co || true

echo
echo "5. DATABASE.PY"
docker exec aibackend sed -n '1,250p' /app/app/database.py

echo
echo "===== DONE ====="
