#!/bin/bash

echo "==============================="
echo "ASTRA PRODUCTION AUDIT"
echo "==============================="

echo
echo "===== Project ====="
pwd
find . -name "*.py" | wc -l
find . -name "*.dart" | wc -l

echo
echo "===== Authentication ====="
grep -RIn "jwt.encode" . 2>/dev/null
grep -RIn "jwt.decode" . 2>/dev/null
grep -RIn "verify_id_token" . 2>/dev/null
grep -RIn "verify_token(" . 2>/dev/null
grep -RIn "create_jwt_token" . 2>/dev/null
grep -RIn "Depends(require_doctor_auth)" . 2>/dev/null
grep -RIn "Depends(get_current_user)" . 2>/dev/null

echo
echo "===== Firebase ====="
grep -RIn "firebase_admin" . 2>/dev/null
grep -RIn "FirebaseAuth" . 2>/dev/null
grep -RIn "verify_firebase_token" . 2>/dev/null

echo
echo "===== Security ====="
grep -RIn "SECRET_KEY" . 2>/dev/null
grep -RIn "JWT_SECRET" . 2>/dev/null
grep -RIn "API_KEY" . 2>/dev/null

echo
echo "===== Prescriptions ====="
grep -RIn "create_prescription" . 2>/dev/null

echo
echo "===== Companion ====="
grep -RIn "companion_manager" . 2>/dev/null
grep -RIn "create_case" . 2>/dev/null

echo
echo "===== Supabase ====="
grep -RIn "supabase" . 2>/dev/null
grep -RIn "on_conflict" . 2>/dev/null

echo
echo "===== Docker ====="
find . -name "Dockerfile"
find . -name "docker-compose.yml"

echo
echo "===== TODO ====="
grep -RIn "TODO\|FIXME\|HACK" . 2>/dev/null

echo
echo "===== Flutter ====="
grep -RIn "Authorization" . 2>/dev/null
grep -RIn "Bearer" . 2>/dev/null
grep -RIn "FirebaseAuth" . 2>/dev/null
grep -RIn "SharedPreferences" . 2>/dev/null

echo
echo "===== Debug ====="
grep -RIn "print(" . 2>/dev/null
grep -RIn "localhost" . 2>/dev/null
grep -RIn "127.0.0.1" . 2>/dev/null

echo
echo "===== COMPLETE ====="
