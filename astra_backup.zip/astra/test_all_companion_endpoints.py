import requests
import json
import uuid
import sys

BASE_URL = "https://astra.ayureze.in"
API_KEY = "astra-secret-2026"
HEADERS = {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json"
}

def print_result(name, r):
    print(f"[{name}]")
    print(f"  Status: {r.status_code}")
    try:
        data = r.json()
        print(f"  Response: {json.dumps(data, indent=2)[:400]}...")
    except Exception:
        print(f"  Response (Text): {r.text[:400]}...")
    print("-" * 50)

def test_companion():
    user_id = f"PAT-TEST-{uuid.uuid4().hex[:6]}"
    doctor_id = "DOC-TEST-99"
    journey_id = None
    case_id = None

    print("==================================================")
    print("STARTING TEST FOR ALL COMPANION ENDPOINTS (V1 & V2)")
    print("==================================================")

    # 1. Start Journey V1
    start_payload = {
        "user_id": user_id,
        "health_concern": "Frequent severe migraines and neck stiffness",
        "language": "en",
        "initial_symptoms": ["headache", "stiffness"]
    }
    url = f"{BASE_URL}/api/companion/journey/start"
    print(f"1. POST {url}")
    try:
        r = requests.post(url, json=start_payload, headers=HEADERS, timeout=15)
        print_result("Start Journey V1", r)
        if r.status_code == 200:
            journey_id = r.json().get("journey_id")
    except Exception as e:
        print(f"Error: {e}")

    if not journey_id:
        print("Failed to get journey_id, generating dummy one for testing.")
        journey_id = f"journey_{uuid.uuid4().hex[:8]}"

    # 2. Companion Chat V1
    chat_payload = {
        "journey_id": journey_id,
        "message": "My head is bursting. What Ayurvedic diet should I follow?",
        "language": "en"
    }
    url = f"{BASE_URL}/api/companion/chat"
    print(f"2. POST {url}")
    try:
        r = requests.post(url, json=chat_payload, headers=HEADERS, timeout=20)
        print_result("Companion Chat V1", r)
    except Exception as e:
        print(f"Error: {e}")

    # 3. Get Journey V1
    url = f"{BASE_URL}/api/companion/journey/{journey_id}"
    print(f"3. GET {url}")
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        print_result("Get Journey V1", r)
    except Exception as e:
        print(f"Error: {e}")

    # 4. Get User Journeys V1
    url = f"{BASE_URL}/api/companion/journey/user/{user_id}"
    print(f"4. GET {url}")
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        print_result("Get User Journeys V1", r)
    except Exception as e:
        print(f"Error: {e}")

    # 5. Update Journey Status V1
    url = f"{BASE_URL}/api/companion/journey/{journey_id}/status?status=monitoring&resolution_notes=Patient%20under%20observation"
    print(f"5. PUT {url}")
    try:
        r = requests.put(url, headers=HEADERS, timeout=10)
        print_result("Update Journey Status V1", r)
    except Exception as e:
        print(f"Error: {e}")

    # 6. Create Case V1
    case_payload = {
        "journey_id": journey_id,
        "user_id": user_id,
        "doctor_id": doctor_id,
        "diagnosis": "Vataja Shirashoola (Vata Headache)",
        "treatment_duration_days": 15,
        "follow_up_schedule": ["day3", "day7", "day15"]
    }
    url = f"{BASE_URL}/api/companion/case/create"
    print(f"6. POST {url}")
    try:
        r = requests.post(url, json=case_payload, headers=HEADERS, timeout=15)
        print_result("Create Case V1", r)
        if r.status_code == 200:
            case_id = r.json().get("case_id")
    except Exception as e:
        print(f"Error: {e}")

    if not case_id:
        case_id = f"case_{uuid.uuid4().hex[:8]}"

    # 7. Get Case V1
    url = f"{BASE_URL}/api/companion/case/{case_id}"
    print(f"7. GET {url}")
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        print_result("Get Case V1", r)
    except Exception as e:
        print(f"Error: {e}")

    # 8. Update Case Progress V1
    progress_payload = {
        "case_id": case_id,
        "progress_percentage": 45.5,
        "adherence_score": 85.0,
        "notes": "Patient is taking medicines on time but had a mild trigger on Day 4."
    }
    url = f"{BASE_URL}/api/companion/case/progress"
    print(f"8. PUT {url}")
    try:
        r = requests.put(url, json=progress_payload, headers=HEADERS, timeout=10)
        print_result("Update Case Progress V1", r)
    except Exception as e:
        print(f"Error: {e}")

    # 9. Add Milestone V1
    milestone_payload = {
        "journey_id": journey_id,
        "milestone_type": "adherence",
        "description": "5 consecutive days of perfect adherence achieved"
    }
    url = f"{BASE_URL}/api/companion/milestone/add"
    print(f"9. POST {url}")
    try:
        r = requests.post(url, json=milestone_payload, headers=HEADERS, timeout=10)
        print_result("Add Milestone V1", r)
    except Exception as e:
        print(f"Error: {e}")

    # 10. Get Journey Health Records V1
    url = f"{BASE_URL}/api/companion/journey/{journey_id}/records"
    print(f"10. GET {url}")
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        print_result("Get Journey Records V1", r)
    except Exception as e:
        print(f"Error: {e}")

    # 11. Link Health Record V1
    link_payload = {
        "record_type": "prescription",
        "storj_document_id": "storj_doc_abc123",
        "description": "Initial diagnostic consultation prescription"
    }
    url = f"{BASE_URL}/api/companion/journey/{journey_id}/link-record"
    print(f"11. POST {url}")
    try:
        r = requests.post(url, json=link_payload, headers=HEADERS, timeout=10)
        print_result("Link Health Record V1", r)
    except Exception as e:
        print(f"Error: {e}")

    # 12. Get Conversation History V1
    url = f"{BASE_URL}/api/companion/conversation/{user_id}"
    print(f"12. GET {url}")
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        print_result("Get Conversation History V1", r)
    except Exception as e:
        print(f"Error: {e}")

    print("\n" + "=" * 50)
    print("V2 ENHANCED COMPANION ENDPOINTS")
    print("=" * 50 + "\n")

    user_id_v2 = f"PAT-V2-{uuid.uuid4().hex[:6]}"
    journey_id_v2 = None

    # 13. Start Journey V2
    start_v2_payload = {
        "user_id": user_id_v2,
        "health_concern": "Dry scaling patches with mild itching",
        "language": "en",
        "initial_symptoms": ["scaling", "itching"],
        "enable_voice": False
    }
    url = f"{BASE_URL}/api/companion/v2/journey/start"
    print(f"13. POST {url}")
    try:
        r = requests.post(url, json=start_v2_payload, headers=HEADERS, timeout=15)
        print_result("Start Journey V2", r)
        if r.status_code == 200:
            journey_id_v2 = r.json().get("journey_id")
    except Exception as e:
        print(f"Error: {e}")

    if not journey_id_v2:
        journey_id_v2 = f"journey_v2_{uuid.uuid4().hex[:8]}"

    # 14. Companion Chat V2 (Note: Uses Form data + optional file upload)
    url = f"{BASE_URL}/api/companion/v2/chat"
    print(f"14. POST {url} (Multipart/Form)")
    try:
        form_data = {
            "journey_id": journey_id_v2,
            "message": "I have some dry scaling redness. What does it mean in Ayurveda?",
            "language": "en",
            "enable_voice": "false"
        }
        # Call without sending a file
        headers_form = {"X-API-Key": API_KEY}
        r = requests.post(url, data=form_data, headers=headers_form, timeout=25)
        print_result("Companion Chat V2 (Text Only)", r)
    except Exception as e:
        print(f"Error: {e}")

    # 15. Get Journey V2
    url = f"{BASE_URL}/api/companion/v2/journey/{journey_id_v2}"
    print(f"15. GET {url}")
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        print_result("Get Journey V2", r)
    except Exception as e:
        print(f"Error: {e}")

    # 16. Get Voices V2
    url = f"{BASE_URL}/api/companion/v2/voices"
    print(f"16. GET {url}")
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        print_result("Get Voices V2", r)
    except Exception as e:
        print(f"Error: {e}")

    # 17. Health Check V2
    url = f"{BASE_URL}/api/companion/v2/health"
    print(f"17. GET {url}")
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        print_result("Health Check V2", r)
    except Exception as e:
        print(f"Error: {e}")

    print("==================================================")
    print("COMPANION ENDPOINTS TEST RUN COMPLETE")
    print("==================================================")

if __name__ == "__main__":
    test_companion()
