#!/bin/bash
set -e

echo "===== AUTH ROUTER IMPORT ====="
grep -n "auth_routes" main.py || true

echo
echo "===== INCLUDE ROUTER ====="
grep -n "include_router.*auth" main.py || true

echo
echo "===== AUTH ROUTES FILE ====="
grep -n "APIRouter" app/auth_routes.py | head

echo
echo "===== REGISTERED ROUTERS ====="
grep -n "include_router" main.py
