#!/bin/bash
set -e

cd ~/astra/astra

echo "=================================="
echo " STEP 13 - OPENTELEMETRY TRACING"
echo "=================================="

#########################################
# 1. Install packages
#########################################

grep -q "opentelemetry-sdk" requirements.txt || cat >> requirements.txt <<'REQ'

opentelemetry-api
opentelemetry-sdk
opentelemetry-instrumentation-fastapi
opentelemetry-exporter-otlp
REQ

#########################################
# 2. Create tracing module
#########################################

mkdir -p app/core

cat > app/core/tracing.py <<'PY'
import os

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

try:
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
except Exception:
    OTLPSpanExporter = None

from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor


def setup_tracing(app):
    endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT")

    resource = Resource.create({
        "service.name": "astra-backend"
    })

    provider = TracerProvider(resource=resource)

    if endpoint and OTLPSpanExporter:
        exporter = OTLPSpanExporter(endpoint=endpoint)
        provider.add_span_processor(BatchSpanProcessor(exporter))

    trace.set_tracer_provider(provider)

    FastAPIInstrumentor.instrument_app(app)
PY

#########################################
# 3. Patch main.py
#########################################

grep -q "from app.core.tracing import setup_tracing" main.py || \
sed -i '1i from app.core.tracing import setup_tracing' main.py

grep -q "setup_tracing(app)" main.py || \
sed -i '/setup_metrics(app)/a\
setup_tracing(app)' main.py

#########################################
# 4. Rebuild
#########################################

docker compose down
docker compose build
docker compose up -d

#########################################
# 5. Wait
#########################################

echo
echo "Waiting for startup..."

for i in {1..40}; do
    if curl -fs http://localhost:5001/health >/dev/null 2>&1; then
        break
    fi
    sleep 2
done

#########################################
# 6. Verify
#########################################

echo
echo "===== HEALTH ====="
curl -s http://localhost:5001/health || true

echo
echo "===== VERIFY IMPORT ====="
docker exec aibackend python - <<'PY'
from app.core.tracing import setup_tracing
print("Tracing module imported successfully")
PY

echo
echo "===== BACKEND ====="
docker ps

echo
echo "=================================="
echo " STEP 13 COMPLETE"
echo "=================================="
