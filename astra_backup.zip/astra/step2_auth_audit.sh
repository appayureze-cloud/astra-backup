#!/bin/bash

echo "======================================"
echo " AUTHENTICATION AUDIT"
echo "======================================"

echo
echo "===== AUTH FILES ====="
find app -iname "*auth*" | sort

echo
echo "===== JWT ====="
grep -R "jwt" app --include="*.py" 2>/dev/null

echo
echo "===== get_current_user ====="
grep -R "get_current_user" app --include="*.py" 2>/dev/null

echo
echo "===== OAuth ====="
grep -R "OAuth" app --include="*.py" 2>/dev/null

echo
echo "===== Supabase Auth ====="
grep -R "supabase.auth" app --include="*.py" 2>/dev/null

echo
echo "===== Depends(get_current_user) ====="
grep -R "Depends(get_current_user)" app --include="*.py" 2>/dev/null

echo
echo "===== Login Endpoints ====="
grep -R "@router.post(\"/login" app --include="*.py" 2>/dev/null

echo
echo "===== Register Endpoints ====="
grep -R "@router.post(\"/register" app --include="*.py" 2>/dev/null

echo
echo "======================================"
echo " AUTH AUDIT COMPLETE"
echo "======================================"

