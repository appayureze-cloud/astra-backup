#!/bin/bash
set -e

echo "======================================"
echo " JWT PROTECTION TEST"
echo "======================================"

ENDPOINTS=(
"/api/v1/auth/user"
"/api/v1/brain/chat"
"/api/v1/video/history"
)

for ep in "${ENDPOINTS[@]}"; do
    echo
    echo "Testing $ep"
    code=$(curl -s -o /tmp/out -w "%{http_code}" http://localhost:5001$ep)
    echo "HTTP $code"
    cat /tmp/out
    echo
done

echo
echo "======================================"
echo " TEST COMPLETE"
echo "======================================"
