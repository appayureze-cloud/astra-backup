import paramiko
import json

def verify_remote_endpoints():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        print("Connecting to VPS...")
        ssh.connect('82.25.105.156', username='root', password='Ayureze@369369', timeout=10)
        print("Connected.")
        
        endpoints = [
            "http://localhost:5001/",
            "http://localhost:5001/health",
            "http://localhost:5001/api/v1/health",
            "http://localhost:5001/v1/",
            "http://localhost:5001/v1/health",
            "https://astra.ayureze.in/api/v1/health",
            "https://astra.ayureze.in/v1/health",
        ]
        
        for ep in endpoints:
            print(f"\n--- Curl testing: {ep} ---")
            # Using -k/--insecure in case of self-signed certs or local routing
            cmd = f"curl -k -i -s -o - -w '\\nHTTP_STATUS:%{{http_code}}\\n' {ep}"
            stdin, stdout, stderr = ssh.exec_command(cmd)
            exit_status = stdout.channel.recv_exit_status()
            
            output = stdout.read().decode('utf-8', 'ignore')
            print(output)
            
    except Exception as e:
        print(f"Failed: {e}")
    finally:
        ssh.close()

if __name__ == "__main__":
    verify_remote_endpoints()
