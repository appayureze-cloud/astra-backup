#!/bin/bash
set -e

echo "======================================"
echo " FIREBASE CONFIG CHECK"
echo "======================================"

echo
echo "1. Firebase Service Account"
find . -iname "*firebase*.json" -o -iname "*service*.json"

echo
echo "2. Environment Variables"
docker exec aibackend env | grep -i FIREBASE || true

echo
echo "3. Firebase Initialization"
grep -R "firebase_admin.initialize_app" app . --include="*.py" 2>/dev/null || true

echo
echo "4. Token Verification"
grep -R "verify_id_token" app . --include="*.py" 2>/dev/null || true

echo
echo "======================================"
echo " FIREBASE CHECK COMPLETE"
echo "======================================"
