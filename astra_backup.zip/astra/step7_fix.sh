#!/bin/bash
set -e

echo "===== FIXING STEP 7 ====="

python3 <<'PY'
from pathlib import Path

p = Path("main.py")
text = p.read_text()

# Remove any bad injected middleware line
text = text.replace("app.add_middleware(SecurityMiddleware)\n", "")

# Find end of FastAPI constructor
needle = 'redoc_url="/astra/redoc"\n)\n'

if needle in text:
    text = text.replace(
        needle,
        needle + "\napp.add_middleware(SecurityMiddleware)\n",
        1
    )

p.write_text(text)
print("main.py repaired")
PY

docker compose down
docker compose build
docker compose up -d

echo
echo "Waiting..."
sleep 25

echo
curl http://localhost:5001/health

echo
docker ps
