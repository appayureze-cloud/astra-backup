#!/bin/bash

BASE=http://localhost:5001

ENDPOINTS=(
"/health"
"/api/v1/health"
"/astra/docs"
"/openapi.json"

"/api/v1/auth/health"

"/api/v1/patients/register"
"/api/v1/orders/prescription/save"
"/api/v1/documents/upload"
"/api/v1/notifications/service-status"
"/api/v1/shopify/health"
"/api/v1/astra-fill/process-text"
"/api/v1/video/history"
"/api/v1/api/doctors/nearby/search"
"/api/v1/api/prescriptions/status"
"/api/v1/api/reminders/health"
"/api/v1/api/translate/status"
"/api/v1/api/ai-agent/status"
"/api/v1/autopilot/status/test"
"/api/v1/chat/sessions"
"/api/companion/v2/health"
)

echo "=============================================="
echo "ASTRA PRODUCTION ENDPOINT TEST"
echo "=============================================="

PASS=0
FAIL=0

for ep in "${ENDPOINTS[@]}"
do
    code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE$ep")

    if [[ "$code" =~ ^(200|201|204|401|403|405|422)$ ]]; then
        printf "✅ %-50s %s\n" "$ep" "$code"
        PASS=$((PASS+1))
    else
        printf "❌ %-50s %s\n" "$ep" "$code"
        FAIL=$((FAIL+1))
    fi
done

echo
echo "=============================================="
echo "PASSED : $PASS"
echo "FAILED : $FAIL"
echo "=============================================="

echo
echo "Recent Tracebacks:"
docker logs aibackend --tail 300 2>&1 | grep -i traceback || echo "None"

echo
echo "Recent 500 Errors:"
docker logs aibackend --tail 300 2>&1 | grep '" 500 ' || echo "None"

echo
echo "Container Health:"
docker ps --filter name=aibackend
