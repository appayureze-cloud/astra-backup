#!/bin/bash
set -e

echo "===== Astra Security Patch ====="

MAIN=main.py

#########################################
# 1. Add imports
#########################################

grep -q "SlowAPIMiddleware" $MAIN || sed -i '/from fastapi/a\
from slowapi.middleware import SlowAPIMiddleware\
from slowapi.errors import RateLimitExceeded\
from app.core.security import limiter, rate_limit_handler\
from fastapi.middleware.gzip import GZipMiddleware' $MAIN

#########################################
# 2. Register limiter
#########################################

grep -q "app.state.limiter" $MAIN || \
sed -i '/app *= *FastAPI/a\
app.state.limiter = limiter' $MAIN

#########################################
# 3. Register middleware
#########################################

grep -q "SlowAPIMiddleware" $MAIN || true

grep -q "app.add_middleware(GZipMiddleware" $MAIN || \
cat >> $MAIN <<'PY'

# --------------------------
# Global Middleware
# --------------------------

app.add_exception_handler(
    RateLimitExceeded,
    rate_limit_handler
)

app.add_middleware(SlowAPIMiddleware)

app.add_middleware(
    GZipMiddleware,
    minimum_size=1024
)

PY

#########################################
# 4. Rebuild
#########################################

echo "Building Docker..."

docker compose build

docker compose up -d

echo
echo "Waiting..."
sleep 15

#########################################
# 5. Verify
#########################################

echo
echo "===== HEALTH ====="

curl -s http://localhost:5001/health

echo
echo

echo "===== Reminder Health ====="

curl -s http://localhost:5001/api/v1/api/reminders/health

echo
echo

echo "===== GZIP ====="

curl -I \
-H "Accept-Encoding: gzip" \
http://localhost:5001/health

echo
echo

echo "Done."
