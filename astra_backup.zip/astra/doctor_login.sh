#!/bin/bash
set -e

BASE=http://127.0.0.1:5001

# ---- CHANGE THIS TO THE DOCTOR'S FIREBASE UID ----
DOCTOR_UID="REPLACE_WITH_DOCTOR_FIREBASE_UID"

API_KEY=$(grep FIREBASE_API_KEY /root/astra/astra/.env | cut -d= -f2)

echo "1. Create Firebase custom token"

CUSTOM_TOKEN=$(docker exec aibackend python - <<PY
import firebase_admin
from firebase_admin import credentials, auth
try:
    firebase_admin.get_app()
except ValueError:
    firebase_admin.initialize_app(
        credentials.Certificate("/app/firebase-service-account.json")
    )
print(auth.create_custom_token("$DOCTOR_UID").decode())
PY
)

echo "2. Exchange for Firebase ID token"

ID_TOKEN=$(curl -s \
"https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=$API_KEY" \
-H "Content-Type: application/json" \
-d "{\"token\":\"$CUSTOM_TOKEN\",\"returnSecureToken\":true}" \
| python3 -c 'import sys,json;print(json.load(sys.stdin)["idToken"])')

echo "3. Create Astra session"

SESSION=$(curl -s -X POST \
$BASE/api/v1/auth/session \
-H "Authorization: Bearer $ID_TOKEN")

echo "$SESSION" | python3 -m json.tool

export ACCESS_TOKEN=$(echo "$SESSION" | python3 -c 'import sys,json;print(json.load(sys.stdin)["access_token"])')

echo
echo "4. Verify role"

curl -s \
-H "Authorization: Bearer $ACCESS_TOKEN" \
$BASE/api/v1/auth/user | python3 -m json.tool

echo
echo "Done."
