#!/bin/bash
set -e

python3 <<'PY'
from pathlib import Path

p = Path("main.py")
text = p.read_text()

# Remove all previous setup_json_logging() calls
text = text.replace("setup_json_logging()\n", "")

# Remove duplicate imports
lines = []
for line in text.splitlines():
    if line.strip() == "from app.core.json_logging import setup_json_logging":
        continue
    lines.append(line)

text = "\n".join(lines)

# Insert import after the last import statement
lines = text.splitlines()
insert = 0
for i, line in enumerate(lines):
    if line.startswith("import ") or line.startswith("from "):
        insert = i + 1

lines.insert(insert, "from app.core.json_logging import setup_json_logging")

text = "\n".join(lines)

# Insert call after logger creation
target = 'logger = logging.getLogger("AstraSecurityFortress")'

text = text.replace(
    target,
    target + "\nsetup_json_logging()",
    1,
)

p.write_text(text)

print("main.py repaired")
PY

docker compose down
docker compose build
docker compose up -d

echo
echo "Waiting..."
sleep 25

echo
curl http://localhost:5001/health

echo
docker logs --tail=20 aibackend
