import sys
import os

# Add the root directory to path so we can import app
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    from app.main import app
    print("=== REGISTERED ROUTES ===")
    for route in app.routes:
        methods = getattr(route, "methods", "None")
        print(f"{methods}: {route.path}")
except Exception as e:
    import traceback
    traceback.print_exc()
