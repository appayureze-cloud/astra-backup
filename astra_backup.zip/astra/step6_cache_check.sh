#!/bin/bash
set -e

echo "=================================="
echo " STEP 6 - REDIS CACHE VERIFICATION"
echo "=================================="

echo
echo "1) Backend status"
docker ps

echo
echo "2) Python test"
docker exec aibackend python -c "print('Python OK')"

echo
echo "3) Cache manager exists?"
docker exec aibackend test -f /app/app/core/cache_manager.py \
&& echo "✓ cache_manager.py found" \
|| { echo "❌ cache_manager.py missing"; exit 1; }

echo
echo "4) Import cache manager"
docker exec aibackend python - <<'PY'
from app.core.cache_manager import cache

print("Imported OK")
print("Redis enabled:", cache.enabled)

cache.set("astra:test", {"hello":"world"}, 60)

print("Cache:", cache.get("astra:test"))
PY

echo
echo "5) Redis container"

if docker ps --format '{{.Names}}' | grep -q '^redis$'; then
    echo "✓ Redis already running"
else
    echo "Installing Redis..."

    if ! grep -q "redis:" docker-compose.yml; then
cat >> docker-compose.yml <<'YAML'

  redis:
    image: redis:7-alpine
    container_name: redis
    restart: unless-stopped
    ports:
      - "6379:6379"
YAML
    fi

    docker compose up -d redis
fi

echo
echo "6) Waiting..."
sleep 5

echo
docker exec redis redis-cli ping || true

echo
echo "7) Restart backend"
docker compose up -d --build aibackend

sleep 20

echo
curl http://localhost:5001/health

echo
echo "Finished."
