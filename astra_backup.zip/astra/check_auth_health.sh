#!/bin/bash
set -e

echo "======================================"
echo " ASTRA AUTH HEALTH CHECK"
echo "======================================"

echo
echo "1. Backend Health"
curl -fs http://localhost:5001/health && echo "  ✓"

echo
echo "2. Auth Health"
curl -i http://localhost:5001/auth/health

echo
echo "3. Auth Routes"
docker exec aibackend python - <<'PY'
import main
for r in sorted(main.app.routes, key=lambda x: x.path):
    if "auth" in r.path.lower():
        print(f"{','.join(r.methods):12} {r.path}")
PY

echo
echo "======================================"
echo " AUTH HEALTH CHECK COMPLETE"
echo "======================================"
