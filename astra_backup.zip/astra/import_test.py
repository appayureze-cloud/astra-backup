import importlib
import traceback

mods = [
"app.auth_routes",
"app.doctors.doctor_routes",
"app.patient_management",
"app.brain_api",
"app.prescriptions.prescription_routes",
"app.catchy_prescription.routes",
"app.unified_prescription_workflow",
"app.smart_auto_cart",
"app.astra_fill.routes",
"app.documents.routes",
"app.notification_routes",
"app.medicine_reminders.routes",
"app.indictrans2_routes",
"app.ai_agent_api",
"app.treatment_centers.center_routes",
"app.order_management",
"app.astra_autopilot.routes",
"app.admin_routes",
"app.agora_routes",
"app.companion_api",
"app.companion_api_enhanced"
]

print("="*70)
print("MODULE IMPORT TEST")
print("="*70)

for m in mods:
    print(f"\nTesting: {m}")
    try:
        importlib.import_module(m)
        print("✅ SUCCESS")
    except Exception:
        print("❌ FAILED")
        traceback.print_exc()
