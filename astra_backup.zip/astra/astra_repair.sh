#!/bin/bash
set -e

echo "=== ASTRA AUTO REPAIR ==="

cd ~/astra || exit 1

echo "Updating code..."
git pull || true

echo "Stopping containers..."
docker compose down || true

echo "Rebuilding..."
docker compose build --no-cache

echo "Starting..."
docker compose up -d

echo "Waiting..."
sleep 20

echo "Health Check"
curl -s http://localhost:5001/health || true

echo "Container Status"
docker compose ps

echo "Recent Errors"
docker logs --tail=100 aibackend

echo "=== DONE ==="
