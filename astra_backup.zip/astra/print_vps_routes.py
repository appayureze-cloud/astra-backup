import paramiko

def print_vps_routes():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        print("Connecting to VPS...")
        ssh.connect('82.25.105.156', username='root', password='Ayureze@369369', timeout=10)
        print("Connected.")
        
        # Mock TimedRotatingFileHandler with a lambda returning NullHandler
        python_code = (
            "import sys; "
            "import logging; "
            "import logging.handlers; "
            "logging.handlers.TimedRotatingFileHandler = lambda *a, **k: logging.NullHandler(); "
            "sys.path.append('/app'); "
            "from app.main import app; "
            "print('\\n'.join([str(getattr(r, 'methods', '')) + ': ' + r.path for r in app.routes]))"
        )
        cmd = f"docker exec aibackend python3 -c \"{python_code}\""
        stdin, stdout, stderr = ssh.exec_command(cmd)
        exit_status = stdout.channel.recv_exit_status()
        
        print("=== REGISTERED ROUTES IN DOCKER ===")
        print(stdout.read().decode('utf-8', 'ignore'))
        
        err = stderr.read().decode('utf-8', 'ignore')
        if err:
            print("Error output:", err)
            
    except Exception as e:
        print(f"Failed: {e}")
    finally:
        ssh.close()

if __name__ == "__main__":
    print_vps_routes()
