import requests
import json
import uuid

BASE_URL = "https://astra.ayureze.in"
API_KEY = "astra-secret-2026"

# Headers for endpoints requiring bypass
BYPASS_HEADERS = {
    "X-API-Key": API_KEY,
    "Authorization": "Bearer bypass_token",
    "Content-Type": "application/json"
}

# Headers for standard public / client-only endpoints
STANDARD_HEADERS = {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json"
}

def print_result(name, r):
    print(f"[{name}] -> {r.url}")
    print(f"  Status: {r.status_code}")
    try:
        data = r.json()
        print(f"  Response: {json.dumps(data, indent=2)[:500]}...")
    except Exception:
        print(f"  Response (Text): {r.text[:500]}...")
    print("-" * 60)

def test_all_flows():
    print("================================================================")
    print("STARTING TEST FOR ALL SPECIFIED FLOWS (SHOPIFY, FILL, AUTOPILOT, RX)")
    print("================================================================")

    patient_id = f"PAT-TEST-{uuid.uuid4().hex[:6]}"
    prescription_id = f"rx_test_{uuid.uuid4().hex[:6]}"

    # Sample Prescription Payload
    prescription_payload = {
        "prescription_id": prescription_id,
        "patient": {
            "patient_id": patient_id,
            "name": "Flow Test Patient",
            "phone": "+919876543210",
            "email": "test@example.com",
            "age": 30,
            "gender": "Male"
        },
        "doctor": {
            "doctor_id": "doc_test_123",
            "name": "Dr. Test Flow",
            "regn_no": "AY12345"
        },
        "diagnosis": "Vata Headaches (Vataja Shirashoola)",
        "doctor_notes": "Take medicines with warm water after food.",
        "prescriptions": [
            {
                "medicine": "Ashwagandha",
                "quantity": 1,
                "dose": "1 tablet",
                "frequency": "twice_daily",
                "timing": "After Food",
                "duration": "15 days",
                "instructions": "With warm water"
            }
        ]
    }

    # ==========================================
    # 1. SHOPIFY AUTO-CART FLOW
    # ==========================================
    print("\n--- Testing: Shopify Auto-Cart Flow ---")
    
    # 1.1 AI Shop Assist
    url = f"{BASE_URL}/api/v1/shopify/ai-shop-assist"
    payload = {"query": "Ashwagandha", "language": "en"}
    try:
        r = requests.post(url, json=payload, headers=STANDARD_HEADERS, timeout=15)
        print_result("Shopify: AI Shop Assist", r)
    except Exception as e:
        print(f"Error: {e}")

    # 1.2 Validate Prescription
    url = f"{BASE_URL}/api/v1/shopify/validate-prescription"
    try:
        r = requests.post(url, json=prescription_payload, headers=STANDARD_HEADERS, timeout=15)
        print_result("Shopify: Validate Prescription", r)
    except Exception as e:
        print(f"Error: {e}")

    # 1.3 Create Draft Order (Requires Doctor Auth Bypass)
    url = f"{BASE_URL}/api/v1/shopify/draft-order"
    try:
        r = requests.post(url, json=prescription_payload, headers=BYPASS_HEADERS, timeout=20)
        print_result("Shopify: Create Draft Order", r)
    except Exception as e:
        print(f"Error: {e}")

    # 1.4 Create COD Order (Requires Doctor Auth Bypass)
    url = f"{BASE_URL}/api/v1/shopify/real-order-cod"
    try:
        r = requests.post(url, json=prescription_payload, headers=BYPASS_HEADERS, timeout=20)
        print_result("Shopify: Real Order COD", r)
    except Exception as e:
        print(f"Error: {e}")

    # 1.5 Shopify Health
    url = f"{BASE_URL}/api/v1/shopify/health"
    try:
        r = requests.get(url, headers=STANDARD_HEADERS, timeout=10)
        print_result("Shopify: Health Check", r)
    except Exception as e:
        print(f"Error: {e}")

    # ==========================================
    # 2. ASTRA FILL FLOW
    # ==========================================
    print("\n--- Testing: Astra Fill Flow ---")

    # 2.1 Process Text
    url = f"{BASE_URL}/api/v1/astra-fill/process-text"
    form_data = {
        "text": "Patient reports severe migraine for past 3 days accompanied by neck stiffness",
        "user_id": patient_id
    }
    try:
        r = requests.post(url, data=form_data, headers={"X-API-Key": API_KEY}, timeout=15)
        print_result("Astra Fill: Process Text", r)
    except Exception as e:
        print(f"Error: {e}")

    # 2.2 Get Latest Intake
    url = f"{BASE_URL}/api/v1/astra-fill/patient/{patient_id}/latest"
    try:
        r = requests.get(url, headers=STANDARD_HEADERS, timeout=10)
        print_result("Astra Fill: Get Latest Intake", r)
    except Exception as e:
        print(f"Error: {e}")

    # 2.3 Get Intake History
    url = f"{BASE_URL}/api/v1/astra-fill/patient/{patient_id}/history"
    try:
        r = requests.get(url, headers=STANDARD_HEADERS, timeout=10)
        print_result("Astra Fill: Get Intake History", r)
    except Exception as e:
        print(f"Error: {e}")

    # ==========================================
    # 3. AUTOPILOT COMPANION FLOW (Astra Brain AI V1)
    # ==========================================
    print("\n--- Testing: Autopilot Companion Flow ---")

    # 3.1 Chat
    url = f"{BASE_URL}/v1/chat"
    try:
        r = requests.post(url, json={"q": "benefits of amla"}, headers=STANDARD_HEADERS, timeout=15)
        print_result("Autopilot: Chat", r)
    except Exception as e:
        print(f"Error: {e}")

    # 3.2 Autopilot
    url = f"{BASE_URL}/v1/autopilot"
    try:
        r = requests.post(url, json={"q": "severe chest pain spreading to arm"}, headers=STANDARD_HEADERS, timeout=15)
        print_result("Autopilot: Autopilot Severity Check", r)
    except Exception as e:
        print(f"Error: {e}")

    # 3.3 Fill
    url = f"{BASE_URL}/v1/fill"
    try:
        r = requests.post(url, json={"text": "I have headache", "schema_def": "symptoms"}, headers=STANDARD_HEADERS, timeout=15)
        print_result("Autopilot: Fill", r)
    except Exception as e:
        print(f"Error: {e}")

    # 3.4 Analyze Safety
    url = f"{BASE_URL}/v1/analyze_safety"
    try:
        # Note: expects plain text Body
        r = requests.post(url, data="I have sharp chest pains", headers=BYPASS_HEADERS, timeout=15)
        print_result("Autopilot: Analyze Safety", r)
    except Exception as e:
        print(f"Error: {e}")

    # ==========================================
    # 4. DOCTOR PRESCRIPTION FLOW
    # ==========================================
    print("\n--- Testing: Doctor Prescription Flow ---")

    # 4.1 Status
    url = f"{BASE_URL}/api/v1/api/prescriptions/status"
    try:
        r = requests.get(url, headers=STANDARD_HEADERS, timeout=10)
        print_result("Prescription: Status Check", r)
    except Exception as e:
        print(f"Error: {e}")

    # 4.2 Suggest Dosage
    url = f"{BASE_URL}/api/v1/api/prescriptions/suggest-dosage"
    dosage_payload = {
        "medicine_name": "Triphala",
        "patient_age": 30,
        "patient_gender": "Male",
        "symptoms": ["indigestion", "bloating"]
    }
    try:
        r = requests.post(url, json=dosage_payload, headers=STANDARD_HEADERS, timeout=15)
        print_result("Prescription: Suggest Dosage", r)
    except Exception as e:
        print(f"Error: {e}")

    # 4.3 Create Prescription (Phase 3 Draft)
    # The spec for /api/prescriptions/create expects a CreatePrescriptionRequest model
    rx_create_payload = {
        "patient_id": patient_id,
        "patient_name": "Flow Test Patient",
        "patient_phone": "+919876543210",
        "doctor_id": "doctor_test",
        "diagnosis": "Vata Headaches",
        "symptoms": ["headache", "neck stiffness"],
        "medicines": [
            {
                "name": "Ashwagandha",
                "dosage": "500mg",
                "frequency": "twice_daily",
                "timing": "After Food",
                "duration_days": 15,
                "instructions": "Warm water"
            }
        ],
        "lifestyle_advice": "Avoid direct sunlight and dry foods.",
        "auto_process": False
    }

    url = f"{BASE_URL}/api/v1/api/prescriptions/create"
    try:
        r = requests.post(url, json=rx_create_payload, headers=BYPASS_HEADERS, timeout=20)
        print_result("Prescription: Create Prescription", r)
    except Exception as e:
        print(f"Error: {e}")

    # 4.4 Submit Draft
    url = f"{BASE_URL}/api/v1/api/prescriptions/draft"
    try:
        r = requests.post(url, json=rx_create_payload, headers=STANDARD_HEADERS, timeout=20)
        print_result("Prescription: Submit Draft", r)
    except Exception as e:
        print(f"Error: {e}")

    print("================================================================")
    print("ALL SPECIFIED FLOW ENDPOINTS TEST RUN COMPLETE")
    print("================================================================")

if __name__ == "__main__":
    test_all_flows()
