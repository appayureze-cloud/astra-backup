#!/bin/bash

echo "========== ASTRA DIAGNOSTICS =========="

echo
echo "=== Docker Containers ==="
docker ps

echo
echo "=== Docker Compose ==="
docker compose ps

echo
echo "=== Health Check ==="
curl -s http://localhost:5000/health || true

echo
echo "=== Environment ==="
docker exec aibackend env | grep -E "SUPABASE|DATABASE|MYSQL|DB_|REDIS|SHOPIFY|BRAIN|URL"

echo
echo "=== DNS Resolution ==="
docker exec aibackend getent hosts brain.ayureze.in
docker exec aibackend getent hosts google.com

echo
echo "=== Brain API ==="
docker exec aibackend curl -I https://brain.ayureze.in/health || true

echo
echo "=== Recent Backend Errors ==="
docker logs --tail=200 aibackend | grep -Ei "error|exception|traceback|failed|timeout|name or service"

echo
echo "=== Docker Resources ==="
docker stats --no-stream

echo
echo "=== Finished ==="
