#!/bin/bash
echo "===== APP MIDDLEWARE ====="
docker exec aibackend python - <<'PY'
import main

print("\nRegistered middleware:\n")
for m in main.app.user_middleware:
    print(m)
PY

echo
echo "===== ROUTE ====="
docker exec aibackend python - <<'PY'
import main

for r in main.app.routes:
    if "/api/v1/auth/session" in r.path:
        print("PATH:", r.path)
        print("METHODS:", r.methods)
        print("ENDPOINT:", r.endpoint)
        print("DEPENDANTS:", r.dependant.dependencies)
        print()
PY
