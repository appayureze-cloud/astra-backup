#!/bin/bash
set -e

echo "======================================"
echo " AUTH BLOCKER INSPECTION"
echo "======================================"

echo
echo "===== main.py middleware ====="
sed -n '35,95p' main.py

echo
echo "===== SecurityMiddleware ====="
sed -n '1,220p' app/core/security_middleware.py

echo
echo "===== RequestLoggingMiddleware ====="
sed -n '1,200p' app/core/request_logging.py

echo
echo "===== auth_middleware.py ====="
sed -n '1,220p' app/auth_middleware.py 2>/dev/null || true

echo
echo "===== firebase_auth_middleware.py ====="
sed -n '1,220p' app/firebase_auth_middleware.py 2>/dev/null || true

echo
echo "======================================"
echo " DONE"
echo "======================================"
