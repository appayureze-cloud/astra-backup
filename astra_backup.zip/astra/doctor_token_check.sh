#!/bin/bash

BASE=http://127.0.0.1:5001

echo "=================================================="
echo "ASTRA DOCTOR TOKEN CHECK"
echo "=================================================="

echo
echo "1. Running auth patch?"
docker exec aibackend grep -n 'doctor_profiles\|doctors' /app/app/auth_routes.py | sed -n '140,180p'

echo
echo "2. Doctor record"
docker exec aibackend python -c "
from app.database import db_manager
r=db_manager.client.table('doctors').select('*').eq('email','h7kgz53ib4@bltiwd.com').execute()
print(r.data)
"

echo
echo "3. Current JWT"
curl -s \
-H "Authorization: Bearer $ACCESS_TOKEN" \
$BASE/api/v1/auth/user | python3 -m json.tool

echo
echo "4. JWT email"
python3 - <<PY
import os,base64,json
t=os.getenv('ACCESS_TOKEN','')
if t.count('.')!=2:
    print('ACCESS_TOKEN missing')
    raise SystemExit
payload=t.split('.')[1]
payload+='='*(-len(payload)%4)
print(json.dumps(json.loads(base64.urlsafe_b64decode(payload)),indent=2))
PY

echo
echo "=================================================="
echo "RESULT"
echo "=================================================="
echo "If step 2 shows DOC-20 but steps 3/4 show test@astra.ai,"
echo "then you are still using the PATIENT JWT."
echo "You must obtain a NEW Astra JWT from the DOCTOR Firebase account."
