import paramiko

def check_vps_files():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        print("Connecting to VPS...")
        ssh.connect('82.25.105.156', username='root', password='Ayureze@369369', timeout=10)
        print("Connected.")
        
        filepath = "/opt/astra/app/image_analysis.py"
        print(f"\n=== Checking router definitions in: {filepath} ===")
        cmd = f"grep -n -C 5 '@router' {filepath} || tail -n 50 {filepath}"
        stdin, stdout, stderr = ssh.exec_command(cmd)
        exit_status = stdout.channel.recv_exit_status()
        print(stdout.read().decode('utf-8', 'ignore'))
        
    except Exception as e:
        print(f"Failed: {e}")
    finally:
        ssh.close()

if __name__ == "__main__":
    check_vps_files()
