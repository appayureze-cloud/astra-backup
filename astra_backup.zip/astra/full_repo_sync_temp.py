import os
import sys
import time

import paramiko


HOST = "82.25.105.156"
USER = "root"
PASSWORD = "Ayureze@369369"
REMOTE_ROOT = "/opt/astra"

EXCLUDE_DIRS = {".git", "__pycache__", "node_modules", "venv", ".venv"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".pyd", ".log"}
EXCLUDE_FILES = {".env"}


def should_skip(path: str, is_dir: bool = False) -> bool:
    base = os.path.basename(path)
    if is_dir:
        return base in EXCLUDE_DIRS
    if base in EXCLUDE_FILES:
        return True
    return any(base.endswith(suffix) for suffix in EXCLUDE_SUFFIXES)


def mkdir_remote(ssh: paramiko.SSHClient, remote_path: str) -> None:
    ssh.exec_command(f"mkdir -p {remote_path}")[1].channel.recv_exit_status()


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="ignore")
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(HOST, username=USER, password=PASSWORD, timeout=60)
    sftp = ssh.open_sftp()

    mkdir_remote(ssh, REMOTE_ROOT)

    uploaded = 0
    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if not should_skip(d, True)]
        rel_root = os.path.relpath(root, ".")
        if rel_root == ".":
            rel_root = ""
        remote_dir = REMOTE_ROOT if not rel_root else f"{REMOTE_ROOT}/{rel_root.replace('\\', '/')}"
        mkdir_remote(ssh, remote_dir)

        for name in files:
            if should_skip(name):
                continue
            local_path = os.path.join(root, name)
            rel_path = os.path.relpath(local_path, ".").replace("\\", "/")
            remote_path = f"{REMOTE_ROOT}/{rel_path}"
            remote_parent = os.path.dirname(remote_path)
            mkdir_remote(ssh, remote_parent)
            sftp.put(local_path, remote_path)
            uploaded += 1
            if uploaded % 100 == 0:
                print(f"UPLOADED={uploaded}")

    sftp.close()
    print(f"UPLOAD_TOTAL={uploaded}")

    stdin, stdout, stderr = ssh.exec_command(f"docker cp {REMOTE_ROOT}/. aibackend:/app")
    code = stdout.channel.recv_exit_status()
    out = stdout.read().decode("utf-8", "ignore")
    err = stderr.read().decode("utf-8", "ignore")
    if out:
        print(out)
    if err:
        print(err)
    print(f"DOCKER_CP_EXIT={code}")

    stdin, stdout, stderr = ssh.exec_command("docker restart aibackend")
    stdout.channel.recv_exit_status()

    health = ""
    for _ in range(60):
        stdin, stdout, stderr = ssh.exec_command("docker inspect --format '{{.State.Health.Status}}' aibackend 2>/dev/null || echo unknown")
        health = stdout.read().decode("utf-8", "ignore").strip()
        print(f"HEALTH={health}")
        if health == "healthy":
            break
        time.sleep(5)

    stdin, stdout, stderr = ssh.exec_command("docker ps --filter name=aibackend --format '{{.Names}} {{.Status}}'")
    print(stdout.read().decode("utf-8", "ignore"))
    ssh.close()
    return 0 if health == "healthy" else 1


if __name__ == "__main__":
    raise SystemExit(main())
